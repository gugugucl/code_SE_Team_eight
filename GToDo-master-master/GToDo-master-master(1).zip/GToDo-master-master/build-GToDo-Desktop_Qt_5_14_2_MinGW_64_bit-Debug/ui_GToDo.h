/********************************************************************************
** Form generated from reading UI file 'GToDo.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GTODO_H
#define UI_GTODO_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GToDo
{
public:
    QAction *action_3;
    QAction *action_4;
    QAction *action;
    QAction *action_2;
    QAction *action_5;
    QAction *action_6;
    QAction *action_7;
    QAction *action_8;
    QAction *action_cn;
    QAction *action_en;
    QAction *action_kr;
    QAction *action_jp;
    QAction *action_tw;
    QAction *action_13;
    QAction *action_14;
    QAction *action_15;
    QAction *action_16;
    QWidget *centralwidget;
    QSplitter *splitter;
    QStackedWidget *panelList;
    QWidget *panelListPage;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_8;
    QComboBox *boxOrder;
    QLineEdit *editAddItem;
    QPushButton *btnRefresh;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_4;
    QWidget *panelListPage_1;
    QWidget *panelSet;
    QVBoxLayout *verticalLayout_10;
    QTextEdit *editTitle;
    QGridLayout *gridLayout_3;
    QPushButton *btnSetRemind;
    QPushButton *btnSetDdl;
    QComboBox *boxRepeat;
    QDateEdit *editDdl;
    QSpacerItem *horizontalSpacer_7;
    QDateTimeEdit *editRemind;
    QComboBox *boxPriority;
    QComboBox *Crontab;
    QHBoxLayout *horizontalLayout_5;
    QFontComboBox *fontComboBox;
    QComboBox *comboBox;
    QPushButton *pushButton_editcopy;
    QPushButton *pushButton_editcut;
    QPushButton *pushButton_editredo;
    QPushButton *pushButton_editundo;
    QPushButton *pushButton_textcenter;
    QPushButton *pushButton_textjustify;
    QPushButton *pushButton_textleft;
    QPushButton *pushButton_textright;
    QPushButton *pushButton_textbold;
    QPushButton *pushButton_textitalic;
    QPushButton *pushButton_textunder;
    QPushButton *pushButton_background_color;
    QPushButton *pushButton_color;
    QPushButton *update_img;
    QPushButton *Clear_btn;
    QPushButton *pushButton_paste;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_16;
    QTextBrowser *editMsg;
    QHBoxLayout *horizontalLayout_17;
    QTextEdit *editDetail;
    QHBoxLayout *horizontalLayout_15;
    QSpacerItem *horizontalSpacer_15;
    QPushButton *btnDetail;
    QSpacerItem *verticalSpacer;
    QWidget *panelListPage_2;
    QStackedWidget *stackedWidget_login;
    QWidget *page_3;
    QCheckBox *rememberCheckBox;
    QPushButton *pushButton_longinbtn;
    QPushButton *btn_signin;
    QLineEdit *lineEdit_username;
    QLineEdit *lineEdit_password;
    QWidget *page_4;
    QPushButton *pushButton_reg;
    QLineEdit *lineEdit_username_reg;
    QLineEdit *lineEdit_passwd_reg;
    QLineEdit *lineEdit_surepasswd_reg;
    QPushButton *pushButton_regbtn;
    QWidget *widget;
    QWidget *panelListPage_3;
    QPushButton *selectButton;
    QRadioButton *radioButton_male;
    QRadioButton *radioButton_female;
    QPushButton *saveButton;
    QPushButton *QPushButton_out;
    QLabel *avatarLabel;
    QLineEdit *lineEdit_UserName;
    QDateEdit *dateEdit_birthday;
    QLineEdit *lineEdit_wechatId;
    QLineEdit *lineEdit_email;
    QTextEdit *TextEdit_profile;
    QWidget *panelListPage_4;
    QGroupBox *groupBox_2;
    QLineEdit *Selection_lineEdit;
    QPushButton *Selection_Audio;
    QPushButton *Selection_Audio_ok;
    QWidget *panelListPage_5;
    QTextBrowser *textBrowser;
    QWidget *panelListPage_6;
    QPushButton *pushButton_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton_3;
    QFrame *Frame_bg;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QLabel *lbGroup;
    QPushButton *pushButton_menu;
    QPushButton *pushButton_min;
    QPushButton *pushButton_exit;
    QFrame *frame_head;
    QWidget *widget_left;
    QPushButton *pushButton_login;
    QPushButton *sexuality;
    QLabel *label_userName;
    QPushButton *pushButton_login_img;
    QWidget *widget_Group;
    QWidget *panelGroup;
    QVBoxLayout *verticalLayout_7;
    QScrollArea *scrollAreaGroup;
    QWidget *scrollAreaWidgetContents_3;
    QVBoxLayout *verticalLayout_8;
    QWidget *widgetGroup;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_13;
    QLineEdit *editAddGroup;
    QVBoxLayout *layoutGroup;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *btnMyTask;
    QSpacerItem *vSpacer;

    void setupUi(QWidget *GToDo)
    {
        if (GToDo->objectName().isEmpty())
            GToDo->setObjectName(QString::fromUtf8("GToDo"));
        GToDo->resize(1188, 768);
        GToDo->setMinimumSize(QSize(1188, 768));
        GToDo->setMaximumSize(QSize(1188, 768));
        action_3 = new QAction(GToDo);
        action_3->setObjectName(QString::fromUtf8("action_3"));
        action_4 = new QAction(GToDo);
        action_4->setObjectName(QString::fromUtf8("action_4"));
        action = new QAction(GToDo);
        action->setObjectName(QString::fromUtf8("action"));
        action_2 = new QAction(GToDo);
        action_2->setObjectName(QString::fromUtf8("action_2"));
        action_5 = new QAction(GToDo);
        action_5->setObjectName(QString::fromUtf8("action_5"));
        action_6 = new QAction(GToDo);
        action_6->setObjectName(QString::fromUtf8("action_6"));
        action_7 = new QAction(GToDo);
        action_7->setObjectName(QString::fromUtf8("action_7"));
        action_8 = new QAction(GToDo);
        action_8->setObjectName(QString::fromUtf8("action_8"));
        action_cn = new QAction(GToDo);
        action_cn->setObjectName(QString::fromUtf8("action_cn"));
        action_en = new QAction(GToDo);
        action_en->setObjectName(QString::fromUtf8("action_en"));
        action_kr = new QAction(GToDo);
        action_kr->setObjectName(QString::fromUtf8("action_kr"));
        action_jp = new QAction(GToDo);
        action_jp->setObjectName(QString::fromUtf8("action_jp"));
        action_tw = new QAction(GToDo);
        action_tw->setObjectName(QString::fromUtf8("action_tw"));
        action_13 = new QAction(GToDo);
        action_13->setObjectName(QString::fromUtf8("action_13"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/image/set.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_13->setIcon(icon);
        action_14 = new QAction(GToDo);
        action_14->setObjectName(QString::fromUtf8("action_14"));
        action_15 = new QAction(GToDo);
        action_15->setObjectName(QString::fromUtf8("action_15"));
        action_16 = new QAction(GToDo);
        action_16->setObjectName(QString::fromUtf8("action_16"));
        centralwidget = new QWidget(GToDo);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setGeometry(QRect(0, 0, 1191, 783));
        splitter = new QSplitter(centralwidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(240, 70, 931, 686));
        splitter->setMaximumSize(QSize(16777215, 16777215));
        splitter->setLineWidth(0);
        splitter->setOrientation(Qt::Horizontal);
        splitter->setHandleWidth(1);
        panelList = new QStackedWidget(splitter);
        panelList->setObjectName(QString::fromUtf8("panelList"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(8);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(panelList->sizePolicy().hasHeightForWidth());
        panelList->setSizePolicy(sizePolicy);
        panelList->setMinimumSize(QSize(0, 0));
        panelList->setMaximumSize(QSize(16777215, 16777215));
        panelList->setLineWidth(0);
        panelListPage = new QWidget();
        panelListPage->setObjectName(QString::fromUtf8("panelListPage"));
        verticalLayout_11 = new QVBoxLayout(panelListPage);
        verticalLayout_11->setSpacing(0);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(5);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        boxOrder = new QComboBox(panelListPage);
        boxOrder->addItem(QString());
        boxOrder->addItem(QString());
        boxOrder->setObjectName(QString::fromUtf8("boxOrder"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(boxOrder->sizePolicy().hasHeightForWidth());
        boxOrder->setSizePolicy(sizePolicy1);
        boxOrder->setMinimumSize(QSize(0, 32));

        horizontalLayout_8->addWidget(boxOrder);

        editAddItem = new QLineEdit(panelListPage);
        editAddItem->setObjectName(QString::fromUtf8("editAddItem"));
        editAddItem->setMinimumSize(QSize(0, 32));

        horizontalLayout_8->addWidget(editAddItem);

        btnRefresh = new QPushButton(panelListPage);
        btnRefresh->setObjectName(QString::fromUtf8("btnRefresh"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(btnRefresh->sizePolicy().hasHeightForWidth());
        btnRefresh->setSizePolicy(sizePolicy2);
        btnRefresh->setMinimumSize(QSize(0, 32));

        horizontalLayout_8->addWidget(btnRefresh);


        verticalLayout_11->addLayout(horizontalLayout_8);

        scrollArea = new QScrollArea(panelListPage);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setFrameShape(QFrame::Panel);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setLineWidth(0);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_4 = new QWidget();
        scrollAreaWidgetContents_4->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_4"));
        scrollAreaWidgetContents_4->setGeometry(QRect(0, 0, 931, 652));
        scrollArea->setWidget(scrollAreaWidgetContents_4);

        verticalLayout_11->addWidget(scrollArea);

        panelList->addWidget(panelListPage);
        panelListPage_1 = new QWidget();
        panelListPage_1->setObjectName(QString::fromUtf8("panelListPage_1"));
        panelSet = new QWidget(panelListPage_1);
        panelSet->setObjectName(QString::fromUtf8("panelSet"));
        panelSet->setGeometry(QRect(0, 10, 921, 721));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(3);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(panelSet->sizePolicy().hasHeightForWidth());
        panelSet->setSizePolicy(sizePolicy3);
        verticalLayout_10 = new QVBoxLayout(panelSet);
        verticalLayout_10->setSpacing(5);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(5, 5, 5, 5);
        editTitle = new QTextEdit(panelSet);
        editTitle->setObjectName(QString::fromUtf8("editTitle"));
        editTitle->setMinimumSize(QSize(0, 32));
        editTitle->setMaximumSize(QSize(16777215, 32));
        QFont font;
        font.setFamily(QString::fromUtf8("Adobe Arabic"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        editTitle->setFont(font);
        editTitle->setLayoutDirection(Qt::LeftToRight);
        editTitle->setFrameShape(QFrame::NoFrame);
        editTitle->setFrameShadow(QFrame::Plain);
        editTitle->setLineWidth(0);
        editTitle->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        editTitle->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_10->addWidget(editTitle);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        btnSetRemind = new QPushButton(panelSet);
        btnSetRemind->setObjectName(QString::fromUtf8("btnSetRemind"));
        btnSetRemind->setMinimumSize(QSize(0, 32));

        gridLayout_3->addWidget(btnSetRemind, 0, 5, 1, 1);

        btnSetDdl = new QPushButton(panelSet);
        btnSetDdl->setObjectName(QString::fromUtf8("btnSetDdl"));
        btnSetDdl->setMinimumSize(QSize(0, 32));

        gridLayout_3->addWidget(btnSetDdl, 0, 2, 1, 1);

        boxRepeat = new QComboBox(panelSet);
        boxRepeat->addItem(QString());
        boxRepeat->addItem(QString());
        boxRepeat->addItem(QString());
        boxRepeat->addItem(QString());
        boxRepeat->addItem(QString());
        boxRepeat->setObjectName(QString::fromUtf8("boxRepeat"));
        boxRepeat->setMinimumSize(QSize(0, 32));

        gridLayout_3->addWidget(boxRepeat, 0, 3, 1, 1);

        editDdl = new QDateEdit(panelSet);
        editDdl->setObjectName(QString::fromUtf8("editDdl"));
        editDdl->setMinimumSize(QSize(0, 32));
        editDdl->setCalendarPopup(true);

        gridLayout_3->addWidget(editDdl, 0, 1, 1, 1);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_7, 0, 7, 1, 1);

        editRemind = new QDateTimeEdit(panelSet);
        editRemind->setObjectName(QString::fromUtf8("editRemind"));
        editRemind->setMinimumSize(QSize(0, 32));
        editRemind->setCalendarPopup(true);

        gridLayout_3->addWidget(editRemind, 0, 4, 1, 1);

        boxPriority = new QComboBox(panelSet);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/image/image/attention_gray.png"), QSize(), QIcon::Normal, QIcon::Off);
        boxPriority->addItem(icon1, QString());
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/image/image/attention_green.png"), QSize(), QIcon::Normal, QIcon::Off);
        boxPriority->addItem(icon2, QString());
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/image/image/attention_blue.png"), QSize(), QIcon::Normal, QIcon::Off);
        boxPriority->addItem(icon3, QString());
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/image/image/attention_red.png"), QSize(), QIcon::Normal, QIcon::Off);
        boxPriority->addItem(icon4, QString());
        boxPriority->setObjectName(QString::fromUtf8("boxPriority"));
        boxPriority->setMinimumSize(QSize(0, 32));

        gridLayout_3->addWidget(boxPriority, 0, 0, 1, 1);

        Crontab = new QComboBox(panelSet);
        Crontab->addItem(QString());
        Crontab->addItem(QString());
        Crontab->addItem(QString());
        Crontab->addItem(QString());
        Crontab->addItem(QString());
        Crontab->setObjectName(QString::fromUtf8("Crontab"));

        gridLayout_3->addWidget(Crontab, 0, 6, 1, 1);


        verticalLayout_10->addLayout(gridLayout_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        fontComboBox = new QFontComboBox(panelSet);
        fontComboBox->setObjectName(QString::fromUtf8("fontComboBox"));
        fontComboBox->setMinimumSize(QSize(0, 32));
        fontComboBox->setMaximumSize(QSize(16777215, 16777215));

        horizontalLayout_5->addWidget(fontComboBox);

        comboBox = new QComboBox(panelSet);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setMinimumSize(QSize(0, 32));

        horizontalLayout_5->addWidget(comboBox);

        pushButton_editcopy = new QPushButton(panelSet);
        pushButton_editcopy->setObjectName(QString::fromUtf8("pushButton_editcopy"));
        pushButton_editcopy->setMinimumSize(QSize(32, 32));
        pushButton_editcopy->setMaximumSize(QSize(80, 16777215));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/image/copy.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_editcopy->setIcon(icon5);

        horizontalLayout_5->addWidget(pushButton_editcopy);

        pushButton_editcut = new QPushButton(panelSet);
        pushButton_editcut->setObjectName(QString::fromUtf8("pushButton_editcut"));
        pushButton_editcut->setMinimumSize(QSize(32, 32));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/image/cut.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_editcut->setIcon(icon6);

        horizontalLayout_5->addWidget(pushButton_editcut);

        pushButton_editredo = new QPushButton(panelSet);
        pushButton_editredo->setObjectName(QString::fromUtf8("pushButton_editredo"));
        pushButton_editredo->setMinimumSize(QSize(32, 32));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/image/cancel.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_editredo->setIcon(icon7);

        horizontalLayout_5->addWidget(pushButton_editredo);

        pushButton_editundo = new QPushButton(panelSet);
        pushButton_editundo->setObjectName(QString::fromUtf8("pushButton_editundo"));
        pushButton_editundo->setMinimumSize(QSize(32, 32));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/image/reform.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_editundo->setIcon(icon8);

        horizontalLayout_5->addWidget(pushButton_editundo);

        pushButton_textcenter = new QPushButton(panelSet);
        pushButton_textcenter->setObjectName(QString::fromUtf8("pushButton_textcenter"));
        pushButton_textcenter->setMinimumSize(QSize(32, 32));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/image/AlignCenter.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textcenter->setIcon(icon9);

        horizontalLayout_5->addWidget(pushButton_textcenter);

        pushButton_textjustify = new QPushButton(panelSet);
        pushButton_textjustify->setObjectName(QString::fromUtf8("pushButton_textjustify"));
        pushButton_textjustify->setMinimumSize(QSize(32, 32));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/image/Justify.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textjustify->setIcon(icon10);

        horizontalLayout_5->addWidget(pushButton_textjustify);

        pushButton_textleft = new QPushButton(panelSet);
        pushButton_textleft->setObjectName(QString::fromUtf8("pushButton_textleft"));
        pushButton_textleft->setMinimumSize(QSize(32, 32));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/image/AlignLeft.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textleft->setIcon(icon11);

        horizontalLayout_5->addWidget(pushButton_textleft);

        pushButton_textright = new QPushButton(panelSet);
        pushButton_textright->setObjectName(QString::fromUtf8("pushButton_textright"));
        pushButton_textright->setMinimumSize(QSize(32, 32));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/image/AlignRight.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textright->setIcon(icon12);

        horizontalLayout_5->addWidget(pushButton_textright);

        pushButton_textbold = new QPushButton(panelSet);
        pushButton_textbold->setObjectName(QString::fromUtf8("pushButton_textbold"));
        pushButton_textbold->setMinimumSize(QSize(32, 32));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/image/bold.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textbold->setIcon(icon13);

        horizontalLayout_5->addWidget(pushButton_textbold);

        pushButton_textitalic = new QPushButton(panelSet);
        pushButton_textitalic->setObjectName(QString::fromUtf8("pushButton_textitalic"));
        pushButton_textitalic->setMinimumSize(QSize(32, 32));
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/image/italic.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textitalic->setIcon(icon14);

        horizontalLayout_5->addWidget(pushButton_textitalic);

        pushButton_textunder = new QPushButton(panelSet);
        pushButton_textunder->setObjectName(QString::fromUtf8("pushButton_textunder"));
        pushButton_textunder->setMinimumSize(QSize(32, 32));
        QIcon icon15;
        icon15.addFile(QString::fromUtf8(":/image/Underline.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_textunder->setIcon(icon15);

        horizontalLayout_5->addWidget(pushButton_textunder);

        pushButton_background_color = new QPushButton(panelSet);
        pushButton_background_color->setObjectName(QString::fromUtf8("pushButton_background_color"));
        pushButton_background_color->setMinimumSize(QSize(32, 32));
        QIcon icon16;
        icon16.addFile(QString::fromUtf8(":/image/textcolor.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_background_color->setIcon(icon16);

        horizontalLayout_5->addWidget(pushButton_background_color);

        pushButton_color = new QPushButton(panelSet);
        pushButton_color->setObjectName(QString::fromUtf8("pushButton_color"));
        pushButton_color->setMinimumSize(QSize(32, 32));
        QIcon icon17;
        icon17.addFile(QString::fromUtf8(":/image/backgroundcolor.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_color->setIcon(icon17);

        horizontalLayout_5->addWidget(pushButton_color);

        update_img = new QPushButton(panelSet);
        update_img->setObjectName(QString::fromUtf8("update_img"));
        update_img->setMinimumSize(QSize(32, 32));
        QIcon icon18;
        icon18.addFile(QString::fromUtf8(":/image/img.png"), QSize(), QIcon::Normal, QIcon::Off);
        update_img->setIcon(icon18);

        horizontalLayout_5->addWidget(update_img);

        Clear_btn = new QPushButton(panelSet);
        Clear_btn->setObjectName(QString::fromUtf8("Clear_btn"));
        Clear_btn->setMinimumSize(QSize(32, 32));
        QIcon icon19;
        icon19.addFile(QString::fromUtf8(":/image/clear.png"), QSize(), QIcon::Normal, QIcon::Off);
        Clear_btn->setIcon(icon19);

        horizontalLayout_5->addWidget(Clear_btn);

        pushButton_paste = new QPushButton(panelSet);
        pushButton_paste->setObjectName(QString::fromUtf8("pushButton_paste"));
        pushButton_paste->setMinimumSize(QSize(32, 32));
        pushButton_paste->setMaximumSize(QSize(32, 32));
        QIcon icon20;
        icon20.addFile(QString::fromUtf8(":/image/paste.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_paste->setIcon(icon20);

        horizontalLayout_5->addWidget(pushButton_paste);


        verticalLayout_10->addLayout(horizontalLayout_5);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));

        verticalLayout_10->addLayout(verticalLayout);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        editMsg = new QTextBrowser(panelSet);
        editMsg->setObjectName(QString::fromUtf8("editMsg"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(editMsg->sizePolicy().hasHeightForWidth());
        editMsg->setSizePolicy(sizePolicy4);
        editMsg->setMinimumSize(QSize(0, 300));
        editMsg->setMaximumSize(QSize(16777215, 16777215));
        editMsg->viewport()->setProperty("cursor", QVariant(QCursor(Qt::IBeamCursor)));
        editMsg->setFrameShape(QFrame::Panel);
        editMsg->setFrameShadow(QFrame::Plain);
        editMsg->setLineWidth(0);
        editMsg->setReadOnly(false);

        horizontalLayout_16->addWidget(editMsg);


        verticalLayout_10->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        editDetail = new QTextEdit(panelSet);
        editDetail->setObjectName(QString::fromUtf8("editDetail"));
        sizePolicy4.setHeightForWidth(editDetail->sizePolicy().hasHeightForWidth());
        editDetail->setSizePolicy(sizePolicy4);
        editDetail->setMaximumSize(QSize(16777215, 100));
        editDetail->setFrameShape(QFrame::Panel);
        editDetail->setFrameShadow(QFrame::Plain);
        editDetail->setLineWidth(0);

        horizontalLayout_17->addWidget(editDetail);


        verticalLayout_10->addLayout(horizontalLayout_17);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_15);

        btnDetail = new QPushButton(panelSet);
        btnDetail->setObjectName(QString::fromUtf8("btnDetail"));
        btnDetail->setMinimumSize(QSize(120, 60));

        horizontalLayout_15->addWidget(btnDetail);


        verticalLayout_10->addLayout(horizontalLayout_15);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer);

        panelList->addWidget(panelListPage_1);
        panelListPage_2 = new QWidget();
        panelListPage_2->setObjectName(QString::fromUtf8("panelListPage_2"));
        stackedWidget_login = new QStackedWidget(panelListPage_2);
        stackedWidget_login->setObjectName(QString::fromUtf8("stackedWidget_login"));
        stackedWidget_login->setGeometry(QRect(210, 150, 451, 361));
        stackedWidget_login->setLineWidth(0);
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        rememberCheckBox = new QCheckBox(page_3);
        rememberCheckBox->setObjectName(QString::fromUtf8("rememberCheckBox"));
        rememberCheckBox->setGeometry(QRect(290, 160, 101, 21));
        pushButton_longinbtn = new QPushButton(page_3);
        pushButton_longinbtn->setObjectName(QString::fromUtf8("pushButton_longinbtn"));
        pushButton_longinbtn->setGeometry(QRect(302, 290, 101, 51));
        btn_signin = new QPushButton(page_3);
        btn_signin->setObjectName(QString::fromUtf8("btn_signin"));
        btn_signin->setGeometry(QRect(50, 210, 351, 61));
        btn_signin->setCursor(QCursor(Qt::PointingHandCursor));
        lineEdit_username = new QLineEdit(page_3);
        lineEdit_username->setObjectName(QString::fromUtf8("lineEdit_username"));
        lineEdit_username->setGeometry(QRect(50, 20, 351, 41));
        lineEdit_password = new QLineEdit(page_3);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));
        lineEdit_password->setGeometry(QRect(50, 80, 351, 41));
        stackedWidget_login->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        pushButton_reg = new QPushButton(page_4);
        pushButton_reg->setObjectName(QString::fromUtf8("pushButton_reg"));
        pushButton_reg->setGeometry(QRect(50, 230, 351, 61));
        lineEdit_username_reg = new QLineEdit(page_4);
        lineEdit_username_reg->setObjectName(QString::fromUtf8("lineEdit_username_reg"));
        lineEdit_username_reg->setGeometry(QRect(50, 50, 351, 41));
        lineEdit_passwd_reg = new QLineEdit(page_4);
        lineEdit_passwd_reg->setObjectName(QString::fromUtf8("lineEdit_passwd_reg"));
        lineEdit_passwd_reg->setGeometry(QRect(50, 110, 351, 41));
        lineEdit_surepasswd_reg = new QLineEdit(page_4);
        lineEdit_surepasswd_reg->setObjectName(QString::fromUtf8("lineEdit_surepasswd_reg"));
        lineEdit_surepasswd_reg->setGeometry(QRect(50, 170, 351, 41));
        pushButton_regbtn = new QPushButton(page_4);
        pushButton_regbtn->setObjectName(QString::fromUtf8("pushButton_regbtn"));
        pushButton_regbtn->setGeometry(QRect(302, 310, 101, 41));
        stackedWidget_login->addWidget(page_4);
        widget = new QWidget(panelListPage_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(79, 309, 121, 81));
        panelList->addWidget(panelListPage_2);
        panelListPage_3 = new QWidget();
        panelListPage_3->setObjectName(QString::fromUtf8("panelListPage_3"));
        selectButton = new QPushButton(panelListPage_3);
        selectButton->setObjectName(QString::fromUtf8("selectButton"));
        selectButton->setGeometry(QRect(80, 30, 121, 111));
        radioButton_male = new QRadioButton(panelListPage_3);
        radioButton_male->setObjectName(QString::fromUtf8("radioButton_male"));
        radioButton_male->setGeometry(QRect(80, 180, 71, 19));
        radioButton_male->setChecked(true);
        radioButton_female = new QRadioButton(panelListPage_3);
        radioButton_female->setObjectName(QString::fromUtf8("radioButton_female"));
        radioButton_female->setGeometry(QRect(180, 180, 71, 19));
        radioButton_female->setChecked(false);
        saveButton = new QPushButton(panelListPage_3);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));
        saveButton->setGeometry(QRect(80, 500, 161, 51));
        QPushButton_out = new QPushButton(panelListPage_3);
        QPushButton_out->setObjectName(QString::fromUtf8("QPushButton_out"));
        QPushButton_out->setGeometry(QRect(80, 570, 161, 51));
        avatarLabel = new QLabel(panelListPage_3);
        avatarLabel->setObjectName(QString::fromUtf8("avatarLabel"));
        avatarLabel->setGeometry(QRect(240, 30, 131, 111));
        lineEdit_UserName = new QLineEdit(panelListPage_3);
        lineEdit_UserName->setObjectName(QString::fromUtf8("lineEdit_UserName"));
        lineEdit_UserName->setGeometry(QRect(80, 220, 181, 41));
        lineEdit_UserName->setStyleSheet(QString::fromUtf8(""));
        dateEdit_birthday = new QDateEdit(panelListPage_3);
        dateEdit_birthday->setObjectName(QString::fromUtf8("dateEdit_birthday"));
        dateEdit_birthday->setGeometry(QRect(280, 220, 161, 41));
        lineEdit_wechatId = new QLineEdit(panelListPage_3);
        lineEdit_wechatId->setObjectName(QString::fromUtf8("lineEdit_wechatId"));
        lineEdit_wechatId->setGeometry(QRect(80, 280, 181, 41));
        lineEdit_email = new QLineEdit(panelListPage_3);
        lineEdit_email->setObjectName(QString::fromUtf8("lineEdit_email"));
        lineEdit_email->setGeometry(QRect(280, 280, 161, 41));
        TextEdit_profile = new QTextEdit(panelListPage_3);
        TextEdit_profile->setObjectName(QString::fromUtf8("TextEdit_profile"));
        TextEdit_profile->setGeometry(QRect(80, 340, 361, 141));
        TextEdit_profile->setFrameShape(QFrame::NoFrame);
        TextEdit_profile->setFrameShadow(QFrame::Plain);
        TextEdit_profile->setLineWidth(0);
        panelList->addWidget(panelListPage_3);
        panelListPage_4 = new QWidget();
        panelListPage_4->setObjectName(QString::fromUtf8("panelListPage_4"));
        groupBox_2 = new QGroupBox(panelListPage_4);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(70, 200, 531, 131));
        Selection_lineEdit = new QLineEdit(groupBox_2);
        Selection_lineEdit->setObjectName(QString::fromUtf8("Selection_lineEdit"));
        Selection_lineEdit->setGeometry(QRect(20, 50, 381, 41));
        Selection_Audio = new QPushButton(groupBox_2);
        Selection_Audio->setObjectName(QString::fromUtf8("Selection_Audio"));
        Selection_Audio->setGeometry(QRect(410, 50, 91, 41));
        Selection_Audio_ok = new QPushButton(groupBox_2);
        Selection_Audio_ok->setObjectName(QString::fromUtf8("Selection_Audio_ok"));
        Selection_Audio_ok->setGeometry(QRect(410, 50, 91, 41));
        panelList->addWidget(panelListPage_4);
        panelListPage_5 = new QWidget();
        panelListPage_5->setObjectName(QString::fromUtf8("panelListPage_5"));
        textBrowser = new QTextBrowser(panelListPage_5);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(30, 30, 881, 621));
        panelList->addWidget(panelListPage_5);
        panelListPage_6 = new QWidget();
        panelListPage_6->setObjectName(QString::fromUtf8("panelListPage_6"));
        pushButton_2 = new QPushButton(panelListPage_6);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(90, 60, 100, 100));
        QIcon icon21;
        icon21.addFile(QString::fromUtf8(":/image/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon21);
        pushButton_2->setIconSize(QSize(80, 80));
        label = new QLabel(panelListPage_6);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(230, 50, 311, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(panelListPage_6);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(230, 110, 161, 16));
        label_3 = new QLabel(panelListPage_6);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(440, 110, 161, 16));
        label_4 = new QLabel(panelListPage_6);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(230, 220, 521, 401));
        label_4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        label_4->setWordWrap(true);
        pushButton_3 = new QPushButton(panelListPage_6);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(230, 150, 171, 51));
        QIcon icon22;
        icon22.addFile(QString::fromUtf8(":/image/update.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon22);
        panelList->addWidget(panelListPage_6);
        splitter->addWidget(panelList);
        Frame_bg = new QFrame(centralwidget);
        Frame_bg->setObjectName(QString::fromUtf8("Frame_bg"));
        Frame_bg->setGeometry(QRect(230, 9, 948, 750));
        Frame_bg->setFrameShape(QFrame::StyledPanel);
        Frame_bg->setFrameShadow(QFrame::Raised);
        horizontalLayoutWidget = new QWidget(Frame_bg);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 931, 34));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        lbGroup = new QLabel(horizontalLayoutWidget);
        lbGroup->setObjectName(QString::fromUtf8("lbGroup"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Arial"));
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        lbGroup->setFont(font2);

        horizontalLayout_2->addWidget(lbGroup);

        pushButton_menu = new QPushButton(horizontalLayoutWidget);
        pushButton_menu->setObjectName(QString::fromUtf8("pushButton_menu"));
        pushButton_menu->setMinimumSize(QSize(32, 32));
        pushButton_menu->setMaximumSize(QSize(32, 32));
        QIcon icon23;
        icon23.addFile(QString::fromUtf8(":/image/nav.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_menu->setIcon(icon23);

        horizontalLayout_2->addWidget(pushButton_menu);

        pushButton_min = new QPushButton(horizontalLayoutWidget);
        pushButton_min->setObjectName(QString::fromUtf8("pushButton_min"));
        pushButton_min->setMinimumSize(QSize(32, 32));
        pushButton_min->setMaximumSize(QSize(32, 32));
        QIcon icon24;
        icon24.addFile(QString::fromUtf8(":/image/min.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_min->setIcon(icon24);

        horizontalLayout_2->addWidget(pushButton_min);

        pushButton_exit = new QPushButton(horizontalLayoutWidget);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setMinimumSize(QSize(32, 32));
        pushButton_exit->setMaximumSize(QSize(32, 32));
        QIcon icon25;
        icon25.addFile(QString::fromUtf8(":/image/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_exit->setIcon(icon25);

        horizontalLayout_2->addWidget(pushButton_exit);

        frame_head = new QFrame(Frame_bg);
        frame_head->setObjectName(QString::fromUtf8("frame_head"));
        frame_head->setGeometry(QRect(0, 0, 951, 54));
        frame_head->setFrameShape(QFrame::StyledPanel);
        frame_head->setFrameShadow(QFrame::Raised);
        frame_head->raise();
        horizontalLayoutWidget->raise();
        widget_left = new QWidget(centralwidget);
        widget_left->setObjectName(QString::fromUtf8("widget_left"));
        widget_left->setGeometry(QRect(10, 10, 221, 748));
        pushButton_login = new QPushButton(widget_left);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));
        pushButton_login->setGeometry(QRect(60, 40, 80, 80));
        pushButton_login->setMinimumSize(QSize(80, 80));
        pushButton_login->setMaximumSize(QSize(80, 80));
        pushButton_login->setCursor(QCursor(Qt::PointingHandCursor));
        QIcon icon26;
        icon26.addFile(QString::fromUtf8(":/image/default_avatar.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_login->setIcon(icon26);
        pushButton_login->setIconSize(QSize(70, 70));
        pushButton_login->setFlat(true);
        sexuality = new QPushButton(widget_left);
        sexuality->setObjectName(QString::fromUtf8("sexuality"));
        sexuality->setGeometry(QRect(120, 100, 16, 16));
        QIcon icon27;
        icon27.addFile(QString::fromUtf8(":/image/sex.png"), QSize(), QIcon::Normal, QIcon::Off);
        sexuality->setIcon(icon27);
        sexuality->setFlat(true);
        label_userName = new QLabel(widget_left);
        label_userName->setObjectName(QString::fromUtf8("label_userName"));
        label_userName->setGeometry(QRect(-3, 140, 221, 20));
        label_userName->setAlignment(Qt::AlignCenter);
        pushButton_login_img = new QPushButton(widget_left);
        pushButton_login_img->setObjectName(QString::fromUtf8("pushButton_login_img"));
        pushButton_login_img->setGeometry(QRect(60, 40, 80, 80));
        pushButton_login_img->setMinimumSize(QSize(80, 80));
        pushButton_login_img->setMaximumSize(QSize(80, 80));
        pushButton_login_img->setCursor(QCursor(Qt::PointingHandCursor));
        QIcon icon28;
        icon28.addFile(QString::fromUtf8(":/image/avatar.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_login_img->setIcon(icon28);
        pushButton_login_img->setIconSize(QSize(70, 70));
        pushButton_login_img->setFlat(true);
        widget_Group = new QWidget(widget_left);
        widget_Group->setObjectName(QString::fromUtf8("widget_Group"));
        widget_Group->setGeometry(QRect(10, 175, 200, 568));
        panelGroup = new QWidget(widget_Group);
        panelGroup->setObjectName(QString::fromUtf8("panelGroup"));
        panelGroup->setGeometry(QRect(0, 0, 200, 686));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(panelGroup->sizePolicy().hasHeightForWidth());
        panelGroup->setSizePolicy(sizePolicy5);
        panelGroup->setMinimumSize(QSize(200, 0));
        verticalLayout_7 = new QVBoxLayout(panelGroup);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        scrollAreaGroup = new QScrollArea(panelGroup);
        scrollAreaGroup->setObjectName(QString::fromUtf8("scrollAreaGroup"));
        scrollAreaGroup->setFrameShape(QFrame::Panel);
        scrollAreaGroup->setFrameShadow(QFrame::Plain);
        scrollAreaGroup->setLineWidth(0);
        scrollAreaGroup->setWidgetResizable(true);
        scrollAreaWidgetContents_3 = new QWidget();
        scrollAreaWidgetContents_3->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_3"));
        scrollAreaWidgetContents_3->setGeometry(QRect(0, 0, 200, 686));
        verticalLayout_8 = new QVBoxLayout(scrollAreaWidgetContents_3);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        widgetGroup = new QWidget(scrollAreaWidgetContents_3);
        widgetGroup->setObjectName(QString::fromUtf8("widgetGroup"));
        verticalLayout_9 = new QVBoxLayout(widgetGroup);
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        editAddGroup = new QLineEdit(widgetGroup);
        editAddGroup->setObjectName(QString::fromUtf8("editAddGroup"));
        editAddGroup->setMinimumSize(QSize(0, 32));

        horizontalLayout_13->addWidget(editAddGroup);


        verticalLayout_9->addLayout(horizontalLayout_13);

        layoutGroup = new QVBoxLayout();
        layoutGroup->setObjectName(QString::fromUtf8("layoutGroup"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        btnMyTask = new QPushButton(widgetGroup);
        btnMyTask->setObjectName(QString::fromUtf8("btnMyTask"));
        QSizePolicy sizePolicy6(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(btnMyTask->sizePolicy().hasHeightForWidth());
        btnMyTask->setSizePolicy(sizePolicy6);
        btnMyTask->setMinimumSize(QSize(0, 32));

        horizontalLayout_3->addWidget(btnMyTask);


        layoutGroup->addLayout(horizontalLayout_3);


        verticalLayout_9->addLayout(layoutGroup);

        vSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(vSpacer);


        verticalLayout_8->addWidget(widgetGroup);

        scrollAreaGroup->setWidget(scrollAreaWidgetContents_3);

        verticalLayout_7->addWidget(scrollAreaGroup);

        pushButton_login->raise();
        label_userName->raise();
        pushButton_login_img->raise();
        widget_Group->raise();
        sexuality->raise();
        widget_left->raise();
        Frame_bg->raise();
        splitter->raise();

        retranslateUi(GToDo);

        panelList->setCurrentIndex(0);
        stackedWidget_login->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(GToDo);
    } // setupUi

    void retranslateUi(QWidget *GToDo)
    {
        GToDo->setWindowTitle(QCoreApplication::translate("GToDo", "GToDo", nullptr));
#if QT_CONFIG(statustip)
        GToDo->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        action_3->setText(QCoreApplication::translate("GToDo", "\345\270\256\345\212\251\346\226\207\346\241\243", nullptr));
        action_4->setText(QCoreApplication::translate("GToDo", "\345\205\263\344\272\216\345\272\224\347\224\250", nullptr));
        action->setText(QCoreApplication::translate("GToDo", "\346\226\260\345\273\272\347\273\204\345\210\253", nullptr));
        action_2->setText(QCoreApplication::translate("GToDo", "\346\226\260\345\273\272\345\276\205\345\212\236", nullptr));
        action_5->setText(QCoreApplication::translate("GToDo", "\351\273\230\350\256\244\351\243\216\346\240\274", nullptr));
        action_6->setText(QCoreApplication::translate("GToDo", "\351\273\221\350\211\262\351\243\216\346\240\274", nullptr));
        action_7->setText(QCoreApplication::translate("GToDo", "\346\213\237\347\211\251\351\243\216\346\240\274", nullptr));
        action_8->setText(QCoreApplication::translate("GToDo", "\346\211\201\345\271\263\351\243\216\346\240\274", nullptr));
        action_cn->setText(QCoreApplication::translate("GToDo", "\347\256\200\344\275\223\344\270\255\346\226\207", nullptr));
        action_en->setText(QCoreApplication::translate("GToDo", "Eglish", nullptr));
        action_kr->setText(QCoreApplication::translate("GToDo", "\355\225\234\352\265\255\354\226\264", nullptr));
        action_jp->setText(QCoreApplication::translate("GToDo", "\346\227\245\346\234\254\350\252\236", nullptr));
        action_tw->setText(QCoreApplication::translate("GToDo", "\347\271\201\344\275\223\344\270\255\346\226\207", nullptr));
        action_13->setText(QCoreApplication::translate("GToDo", "\345\220\257\345\212\250\350\256\276\347\275\256", nullptr));
        action_14->setText(QCoreApplication::translate("GToDo", "\345\205\263\344\272\216\345\272\224\347\224\250", nullptr));
        action_15->setText(QCoreApplication::translate("GToDo", "\345\270\256\345\212\251\346\226\207\346\241\243", nullptr));
        action_16->setText(QCoreApplication::translate("GToDo", "\345\234\250\347\272\277\345\215\207\347\272\247", nullptr));
        boxOrder->setItemText(0, QCoreApplication::translate("GToDo", "\346\214\211\345\210\260\346\234\237\346\227\266\351\227\264\346\216\222\345\272\217", nullptr));
        boxOrder->setItemText(1, QCoreApplication::translate("GToDo", "\346\214\211\344\274\230\345\205\210\347\272\247\346\216\222\345\272\217", nullptr));

#if QT_CONFIG(statustip)
        boxOrder->setStatusTip(QCoreApplication::translate("GToDo", "\351\200\211\346\213\251\345\276\205\345\212\236\345\210\227\350\241\250\346\216\222\345\272\217\346\226\271\345\274\217\343\200\202", nullptr));
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        editAddItem->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        editAddItem->setText(QString());
        editAddItem->setPlaceholderText(QCoreApplication::translate("GToDo", "\346\267\273\345\212\240\346\226\260\345\276\205\345\212\236\357\274\214\345\234\250\350\276\223\345\205\245\346\241\206\350\276\223\345\205\245\345\276\205\345\212\236\346\240\207\351\242\230\345\233\236\350\275\246\351\224\256\347\241\256\350\256\244\345\215\263\345\217\257\346\267\273\345\212\240\343\200\202", nullptr));
#if QT_CONFIG(statustip)
        btnRefresh->setStatusTip(QCoreApplication::translate("GToDo", "\345\210\267\346\226\260\345\276\205\345\212\236\345\214\272\345\210\227\350\241\250", nullptr));
#endif // QT_CONFIG(statustip)
        btnRefresh->setText(QCoreApplication::translate("GToDo", "\345\210\267\346\226\260", nullptr));
#if QT_CONFIG(statustip)
        scrollArea->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        editTitle->setStatusTip(QCoreApplication::translate("GToDo", "\344\272\213\344\273\266\345\220\215", nullptr));
#endif // QT_CONFIG(statustip)
        editTitle->setHtml(QCoreApplication::translate("GToDo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Adobe Arabic'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'SimSun'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        editTitle->setPlaceholderText(QCoreApplication::translate("GToDo", "\344\272\213\344\273\266\345\220\215", nullptr));
#if QT_CONFIG(statustip)
        btnSetRemind->setStatusTip(QCoreApplication::translate("GToDo", "\347\202\271\345\207\273\350\256\276\347\275\256\346\217\220\351\206\222\346\227\266\351\227\264", nullptr));
#endif // QT_CONFIG(statustip)
        btnSetRemind->setText(QCoreApplication::translate("GToDo", "\346\217\220\351\206\222", nullptr));
        btnSetDdl->setText(QCoreApplication::translate("GToDo", "\346\210\252\350\207\263\346\227\245\346\234\237", nullptr));
        boxRepeat->setItemText(0, QCoreApplication::translate("GToDo", "\344\270\215\351\207\215\345\244\215", nullptr));
        boxRepeat->setItemText(1, QCoreApplication::translate("GToDo", "\346\257\217\346\227\245\351\207\215\345\244\215", nullptr));
        boxRepeat->setItemText(2, QCoreApplication::translate("GToDo", "\346\257\217\345\221\250\351\207\215\345\244\215", nullptr));
        boxRepeat->setItemText(3, QCoreApplication::translate("GToDo", "\346\257\217\346\234\210\351\207\215\345\244\215", nullptr));
        boxRepeat->setItemText(4, QCoreApplication::translate("GToDo", "\346\257\217\345\271\264\351\207\215\345\244\215", nullptr));

        boxPriority->setItemText(0, QCoreApplication::translate("GToDo", "\346\227\240\344\274\230\345\205\210\347\272\247", nullptr));
        boxPriority->setItemText(1, QCoreApplication::translate("GToDo", "\344\275\216", nullptr));
        boxPriority->setItemText(2, QCoreApplication::translate("GToDo", "\344\270\255", nullptr));
        boxPriority->setItemText(3, QCoreApplication::translate("GToDo", "\351\253\230", nullptr));

#if QT_CONFIG(statustip)
        boxPriority->setStatusTip(QCoreApplication::translate("GToDo", "\351\200\211\346\213\251\344\274\230\345\205\210\347\255\211\347\272\247", nullptr));
#endif // QT_CONFIG(statustip)
        Crontab->setItemText(0, QCoreApplication::translate("GToDo", "\344\270\215\345\220\257\347\224\250", nullptr));
        Crontab->setItemText(1, QCoreApplication::translate("GToDo", "\346\211\247\350\241\214\345\205\263\346\234\272\344\273\273\345\212\241", nullptr));
        Crontab->setItemText(2, QCoreApplication::translate("GToDo", "\345\256\232\346\227\266\346\270\205\347\220\206\344\273\273\345\212\241", nullptr));
        Crontab->setItemText(3, QCoreApplication::translate("GToDo", "\345\256\232\346\227\266\345\272\224\347\224\250\344\273\273\345\212\241", nullptr));
        Crontab->setItemText(4, QCoreApplication::translate("GToDo", "\350\207\252\345\256\232\344\271\211\344\273\273\345\212\241", nullptr));

        pushButton_editcopy->setText(QString());
        pushButton_editcut->setText(QString());
        pushButton_editredo->setText(QString());
        pushButton_editundo->setText(QString());
        pushButton_textcenter->setText(QString());
        pushButton_textjustify->setText(QString());
        pushButton_textleft->setText(QString());
        pushButton_textright->setText(QString());
        pushButton_textbold->setText(QString());
        pushButton_textitalic->setText(QString());
        pushButton_textunder->setText(QString());
        pushButton_background_color->setText(QString());
        pushButton_color->setText(QString());
        update_img->setText(QString());
        Clear_btn->setText(QString());
        pushButton_paste->setText(QString());
#if QT_CONFIG(statustip)
        editMsg->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        editMsg->setPlaceholderText(QCoreApplication::translate("GToDo", "\350\276\223\345\205\245\345\276\205\345\212\236\345\206\205\345\256\271 \342\200\246", nullptr));
#if QT_CONFIG(statustip)
        editDetail->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        editDetail->setPlaceholderText(QCoreApplication::translate("GToDo", "\350\276\223\345\205\245\344\273\273\345\212\241\345\244\207\346\263\250 \342\200\246", nullptr));
#if QT_CONFIG(statustip)
        btnDetail->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        btnDetail->setText(QCoreApplication::translate("GToDo", "\345\256\214\346\210\220\346\217\220\344\272\244", nullptr));
        rememberCheckBox->setText(QCoreApplication::translate("GToDo", "\350\256\260\344\275\217\345\257\206\347\240\201", nullptr));
        pushButton_longinbtn->setText(QCoreApplication::translate("GToDo", "\350\267\263\350\275\254\346\263\250\345\206\214", nullptr));
        btn_signin->setText(QCoreApplication::translate("GToDo", "\347\231\273\345\275\225", nullptr));
        lineEdit_username->setPlaceholderText(QCoreApplication::translate("GToDo", "\347\224\250\346\210\267\345\220\215", nullptr));
        lineEdit_password->setPlaceholderText(QCoreApplication::translate("GToDo", "\345\257\206\347\240\201", nullptr));
        pushButton_reg->setText(QCoreApplication::translate("GToDo", "\346\263\250\345\206\214", nullptr));
        lineEdit_username_reg->setPlaceholderText(QCoreApplication::translate("GToDo", "\350\264\246\346\210\267\345\220\215", nullptr));
        lineEdit_passwd_reg->setPlaceholderText(QCoreApplication::translate("GToDo", "\345\257\206\347\240\201", nullptr));
        lineEdit_surepasswd_reg->setPlaceholderText(QCoreApplication::translate("GToDo", "\347\241\256\350\256\244\345\257\206\347\240\201", nullptr));
        pushButton_regbtn->setText(QCoreApplication::translate("GToDo", "\350\267\263\350\275\254\347\231\273\345\275\225", nullptr));
        selectButton->setText(QCoreApplication::translate("GToDo", "\351\200\211\346\213\251\345\244\264\345\203\217", nullptr));
        radioButton_male->setText(QCoreApplication::translate("GToDo", "\347\224\267\347\224\237", nullptr));
        radioButton_female->setText(QCoreApplication::translate("GToDo", "\345\245\263\347\224\237", nullptr));
        saveButton->setText(QCoreApplication::translate("GToDo", "\344\277\235\345\255\230\350\265\204\346\226\231", nullptr));
        QPushButton_out->setText(QCoreApplication::translate("GToDo", "\351\200\200\345\207\272\347\231\273\345\275\225", nullptr));
        avatarLabel->setText(QString());
        lineEdit_UserName->setPlaceholderText(QCoreApplication::translate("GToDo", "\344\277\256\346\224\271\347\224\250\346\210\267\345\220\215", nullptr));
        lineEdit_wechatId->setPlaceholderText(QCoreApplication::translate("GToDo", "\345\276\256\344\277\241ID", nullptr));
        lineEdit_email->setPlaceholderText(QCoreApplication::translate("GToDo", "\351\202\256\347\256\261", nullptr));
        TextEdit_profile->setPlaceholderText(QCoreApplication::translate("GToDo", "\344\270\252\344\272\272\344\273\213\347\273\215", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("GToDo", "\346\217\220\351\206\222\351\237\263\346\225\210", nullptr));
        Selection_lineEdit->setPlaceholderText(QCoreApplication::translate("GToDo", "\350\257\267\351\200\211\346\213\251\351\237\263\346\225\210\346\226\207\344\273\266\350\267\257\345\276\204 \342\200\246", nullptr));
        Selection_Audio->setText(QCoreApplication::translate("GToDo", "\351\200\211\346\213\251\351\237\263\346\225\210", nullptr));
        Selection_Audio_ok->setText(QCoreApplication::translate("GToDo", "\344\277\235\345\255\230", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("GToDo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">GTDO\346\230\257\344\270\200\346\254\276\344\270\223\344\270\232\347\232\204\345\276\205\345\212\236\344\272\213\351\241\271\347\256\241\347\220\206\350\275\257\344\273\266\357\274\214\345\205\266\346\213\245\346\234\211\346\270\205\346\231\260\347\256\200\346\264\201\347\232\204\347\225\214\351\235\242\350\256\276\350\256\241\343\200\201\344\270\245\350\260\250\347\232\204\344\273\273\345\212\241\345\210\206\347\261\273\346\234\272\345\210\266\357\274\214\344\273\245\345\217\212\345\274\272\345\244\247\347\232\204\344\273\273\345\212\241\346\217\220\351\206\222\345"
                        "\212\237\350\203\275\357\274\214\346\267\261\345\217\227\345\271\277\345\244\247\347\224\250\346\210\267\347\232\204\345\226\234\347\210\261\343\200\202\346\234\254\346\226\207\345\260\206\344\270\272\346\202\250\350\257\246\347\273\206\344\273\213\347\273\215GTDO\350\275\257\344\273\266\347\232\204\344\275\277\347\224\250\346\225\231\347\250\213\357\274\214\345\270\256\345\212\251\346\202\250\346\233\264\345\245\275\345\234\260\347\256\241\347\220\206\346\202\250\347\232\204\346\227\245\345\270\270\344\273\273\345\212\241\343\200\202</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\270\200\343\200\201\350\275\257\344\273\266\345\256\211\350\243\205</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\351\246\226\345\205\210\357\274\214\346\210\221\344\273\254\351\234\200\350\246\201\344\270\213\350\275\275\345\271\266\345\256\211\350\243\205GTDO\350"
                        "\275\257\344\273\266\343\200\202\346\202\250\345\217\257\344\273\245\345\234\250\345\256\230\346\226\271\347\275\221\347\253\231[<a href=\"http://www.gtdo.com/\"><span style=\" text-decoration: underline; color:#0000ff;\">1</span></a>]\344\270\212\350\277\233\350\241\214\344\270\213\350\275\275\357\274\214\346\214\211\347\205\247\346\217\220\347\244\272\345\256\214\346\210\220\345\256\211\350\243\205\343\200\202</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\272\214\343\200\201\350\264\246\345\217\267\346\263\250\345\206\214</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\275\223\346\202\250\347\254\254\344\270\200\346\254\241\346\211\223\345\274\200GTDO\350\275\257\344\273\266\346\227\266\357\274\214\351\234\200\350\246\201\346\263\250\345\206\214\344\270\200\344\270\252\346\226\260\350\264\246\345\217\267\343\200\202\350\257\267\346\263"
                        "\250\346\204\217\357\274\214\350\257\245\350\264\246\345\217\267\345\260\206\344\275\234\344\270\272\346\202\250\346\211\200\346\234\211\344\273\273\345\212\241\347\232\204\347\273\237\344\270\200\347\256\241\347\220\206\346\240\207\350\257\206\357\274\214\345\233\240\346\255\244\357\274\214\350\257\267\347\241\256\344\277\235\346\202\250\350\276\223\345\205\245\347\232\204\344\277\241\346\201\257\345\207\206\347\241\256\346\227\240\350\257\257\343\200\202</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\270\211\343\200\201\345\210\233\345\273\272\344\273\273\345\212\241\346\270\205\345\215\225</p>\n"
"<ol style=\"margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;\"><li style=\"\" style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\347\202\271\345\207\273\342\200\234\346\226\260\345\273\272\346\270\205\345\215\225\342"
                        "\200\235\346\214\211\351\222\256\357\274\214\350\276\223\345\205\245\345\210\227\350\241\250\345\220\215\347\247\260\357\274\214\345\271\266\351\200\211\346\213\251\345\210\227\350\241\250\346\230\276\347\244\272\351\242\234\350\211\262\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\347\202\271\345\207\273\342\200\234\346\267\273\345\212\240\344\273\273\345\212\241\342\200\235\346\214\211\351\222\256\357\274\214\350\276\223\345\205\245\344\273\273\345\212\241\345\220\215\347\247\260\343\200\201\346\210\252\346\255\242\346\227\245\346\234\237\345\222\214\344\274\230\345\205\210\347\272\247\347\255\211\344\277\241\346\201\257\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\346\202\250\345\217\257\344\273\245\346\240\271\346\215\256\351\234\200\350\246\201\346\267\273\345\212\240\345\255\220\344\273\273"
                        "\345\212\241\346\210\226\350\200\205\350\257\204\350\256\272\357\274\214\344\273\245\344\276\277\346\233\264\345\245\275\345\234\260\350\256\260\345\275\225\345\222\214\350\267\237\350\270\252\344\273\273\345\212\241\346\211\247\350\241\214\346\203\205\345\206\265\343\200\202</li></ol>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\233\233\343\200\201\350\256\276\347\275\256\344\273\273\345\212\241\346\217\220\351\206\222</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\273\273\345\212\241\346\217\220\351\206\222\346\230\257GTDO\350\275\257\344\273\266\347\232\204\344\270\200\345\244\247\344\272\256\347\202\271\357\274\214\345\256\203\345\217\257\344\273\245\345\234\250\344\273\273\345\212\241\345\210\260\346\234\237\345\211\215\345\220\221\346\202\250\345\217\221\351\200\201\351\202\256\344\273\266\346\210\226\346\211\213\346\234\272\347\237"
                        "\255\344\277\241\346\217\220\351\206\222\357\274\214\344\277\235\350\257\201\346\202\250\344\270\215\344\274\232\351\224\231\350\277\207\344\273\273\344\275\225\351\207\215\350\246\201\344\273\273\345\212\241\343\200\202</p>\n"
"<ol style=\"margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;\"><li style=\"\" style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\347\202\271\345\207\273\344\273\273\345\212\241\345\220\215\347\247\260\357\274\214\345\234\250\345\274\271\345\207\272\347\232\204\347\274\226\350\276\221\351\241\265\351\235\242\344\270\255\351\200\211\346\213\251\342\200\234\346\217\220\351\206\222\342\200\235\346\240\207\347\255\276\351\241\265\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\351\200\211\346\213\251\346\202\250\351\234\200\350\246\201\347\232\204\346\217\220\351\206\222\346"
                        "\226\271\345\274\217\357\274\214\344\276\213\345\246\202\351\202\256\344\273\266\346\210\226\350\200\205\347\237\255\344\277\241\357\274\214\345\271\266\350\256\276\347\275\256\346\217\220\351\206\222\346\227\266\351\227\264\345\222\214\351\242\221\347\216\207\347\255\211\344\277\241\346\201\257\343\200\202</li></ol>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\272\224\343\200\201\344\273\273\345\212\241\345\210\206\347\261\273</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\273\273\345\212\241\345\210\206\347\261\273\346\230\257GTDO\350\275\257\344\273\266\347\232\204\345\217\246\344\270\200\351\207\215\350\246\201\345\212\237\350\203\275\357\274\214\345\256\203\345\217\257\344\273\245\345\270\256\345\212\251\346\202\250\346\233\264\345\245\275\345\234\260\347\256\241\347\220\206\346\202\250\347\232\204\344\273\273\345\212\241\346\270\205"
                        "\345\215\225\357\274\214\344\276\213\345\246\202\346\240\271\346\215\256\345\267\245\344\275\234\351\241\271\347\233\256\343\200\201\346\210\252\346\255\242\346\227\245\346\234\237\346\210\226\350\200\205\344\274\230\345\205\210\347\272\247\347\255\211\344\277\241\346\201\257\345\210\206\347\261\273\343\200\202</p>\n"
"<ol style=\"margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;\"><li style=\"\" style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\347\202\271\345\207\273\345\267\246\344\276\247\350\217\234\345\215\225\344\270\255\347\232\204\342\200\234\345\210\206\347\261\273\342\200\235\357\274\214\345\271\266\351\200\211\346\213\251\344\270\200\344\270\252\345\210\206\347\261\273\345\220\215\347\247\260\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\347\202\271\345\207\273\345\217\263\344\276"
                        "\247\347\232\204\342\200\234\346\267\273\345\212\240\346\226\260\346\270\205\345\215\225\342\200\235\346\214\211\351\222\256\357\274\214\345\271\266\350\276\223\345\205\245\346\270\205\345\215\225\345\220\215\347\247\260\345\222\214\351\242\234\350\211\262\347\255\211\344\277\241\346\201\257\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\260\206\344\273\273\345\212\241\346\213\226\346\213\275\345\210\260\347\233\270\345\272\224\347\232\204\346\270\205\345\215\225\344\270\255\357\274\214\345\215\263\345\217\257\345\256\214\346\210\220\345\210\206\347\261\273\343\200\202</li></ol>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\205\255\343\200\201\345\210\233\345\273\272\346\250\241\346\235\277</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0p"
                        "x;\">\345\257\271\344\272\216\351\207\215\345\244\215\346\200\247\347\232\204\344\273\273\345\212\241\357\274\214\346\210\221\344\273\254\345\217\257\344\273\245\344\275\277\347\224\250\346\250\241\346\235\277\346\235\245\345\277\253\351\200\237\345\210\233\345\273\272\346\226\260\344\273\273\345\212\241\343\200\202GTDO\350\275\257\344\273\266\346\217\220\344\276\233\344\272\206\344\270\200\344\270\252\346\230\223\344\272\216\344\275\277\347\224\250\347\232\204\346\250\241\346\235\277\345\212\237\350\203\275\357\274\214\350\256\251\346\202\250\345\217\257\344\273\245\350\275\273\346\235\276\345\210\233\345\273\272\344\273\273\345\212\241\346\250\241\346\235\277\357\274\214\344\273\245\344\276\277\346\233\264\345\245\275\345\234\260\347\256\241\347\220\206\344\273\273\345\212\241\343\200\202</p>\n"
"<ol style=\"margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;\"><li style=\"\" style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-in"
                        "dent:0; text-indent:0px;\">\347\202\271\345\207\273\342\200\234\346\226\260\345\273\272\346\270\205\345\215\225\342\200\235\346\214\211\351\222\256\357\274\214\345\234\250\345\274\271\345\207\272\347\232\204\351\241\265\351\235\242\344\270\255\351\200\211\346\213\251\342\200\234\346\250\241\346\235\277\345\210\266\344\275\234\342\200\235\351\200\211\351\241\271\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\350\276\223\345\205\245\346\250\241\346\235\277\345\220\215\347\247\260\345\222\214\346\217\217\350\277\260\344\277\241\346\201\257\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\346\267\273\345\212\240\346\250\241\346\235\277\344\273\273\345\212\241\357\274\214\345\271\266\350\256\276\347\275\256\345\245\275\345\205\266\345\237\272\346\234\254\344\277\241\346\201\257\345\217\212\346\217\220\351"
                        "\206\222\346\226\271\345\274\217\347\255\211\343\200\202</li>\n"
"<li style=\"\" style=\" margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\256\214\346\210\220\346\250\241\346\235\277\345\210\233\345\273\272\345\220\216\357\274\214\345\234\250\346\227\245\345\270\270\344\275\277\347\224\250\346\227\266\357\274\214\345\217\252\351\234\200\345\234\250\346\226\260\345\273\272\344\273\273\345\212\241\346\227\266\351\200\211\346\213\251\347\233\270\345\272\224\347\232\204\346\250\241\346\235\277\345\215\263\345\217\257\343\200\202</li></ol>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\270\203\343\200\201\346\200\273\347\273\223</p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\351\200\232\350\277\207\344\273\245\344\270\212\346\255\245\351\252\244\357\274\214\346\210\221\344\273\254\345"
                        "\267\262\347\273\217\345\217\257\344\273\245\345\256\214\346\225\264\345\234\260\344\275\277\347\224\250GTDO\345\276\205\345\212\236\344\270\223\345\256\266\350\277\233\350\241\214\344\273\273\345\212\241\347\256\241\347\220\206\343\200\202\345\260\206\346\211\200\346\234\211\344\273\273\345\212\241\346\224\266\351\233\206\345\210\260\346\270\205\345\215\225\344\270\255\357\274\214\345\271\266\346\240\271\346\215\256\345\205\266\344\274\230\345\205\210\347\272\247\343\200\201\346\210\252\346\255\242\346\227\245\346\234\237\345\222\214\345\210\206\347\261\273\346\235\245\347\256\241\347\220\206\345\222\214\350\267\237\350\270\252\344\273\273\345\212\241\347\232\204\346\211\247\350\241\214\346\203\205\345\206\265\357\274\214\345\220\214\346\227\266\351\200\232\350\277\207\345\274\272\345\244\247\347\232\204\346\217\220\351\206\222\345\212\237\350\203\275\345\222\214\344\273\273\345\212\241\346\250\241\346\235\277\347\255\211\345\267\245\345\205\267\357\274\214\346\234\211\346\225\210\345\234\260\346\217\220\351\253"
                        "\230\344\272\206\345\267\245\344\275\234\346\225\210\347\216\207\343\200\202</p></body></html>", nullptr));
        pushButton_2->setText(QString());
        label->setText(QCoreApplication::translate("GToDo", "GTDO\345\276\205\345\212\236\344\270\223\345\256\266", nullptr));
        label_2->setText(QCoreApplication::translate("GToDo", "\345\275\223\345\211\215\347\211\210\346\234\254\357\274\232 v1.0.01", nullptr));
        label_3->setText(QCoreApplication::translate("GToDo", "\346\234\200\346\226\260\347\211\210\346\234\254\357\274\232 v1.2.01", nullptr));
        label_4->setText(QCoreApplication::translate("GToDo", "<html><head/><body><p>GTDO\345\276\205\345\212\236\344\270\223\345\256\266\346\230\257\344\270\200\346\254\276\351\253\230\346\225\210\347\232\204\344\273\273\345\212\241\347\256\241\347\220\206\350\275\257\344\273\266\357\274\214\345\256\203\345\217\257\344\273\245\345\270\256\345\212\251\347\224\250\346\210\267\350\275\273\346\235\276\347\256\241\347\220\206\346\227\245\345\270\270\344\273\273\345\212\241\357\274\214\345\256\236\347\216\260\351\253\230\346\225\210\345\267\245\344\275\234\343\200\201\351\253\230\345\223\201\350\264\250\347\224\237\346\264\273\343\200\202\350\257\245\350\275\257\344\273\266\346\217\220\344\276\233\344\270\200\347\263\273\345\210\227\345\256\236\347\224\250\347\232\204\345\212\237\350\203\275\357\274\214\345\246\202\346\270\205\345\215\225\347\256\241\347\220\206\343\200\201\344\273\273\345\212\241\345\210\206\347\261\273\343\200\201\344\273\273\345\212\241\346\217\220\351\206\222\343\200\201\344\273\273\345\212\241\346\250\241\346\235\277\347\255\211\357\274\214\345\270\256\345"
                        "\212\251\347\224\250\346\210\267\346\234\211\346\225\210\345\234\260\350\247\204\345\210\222\344\273\273\345\212\241\346\227\266\351\227\264\357\274\214\346\217\220\351\253\230\345\267\245\344\275\234\346\225\210\347\216\207\343\200\202</p><p>GTDO\345\276\205\345\212\236\344\270\223\345\256\266\347\232\204\346\224\266\351\233\206\345\212\237\350\203\275\357\274\214\350\256\251\347\224\250\346\210\267\345\217\257\344\273\245\345\260\206\346\211\200\346\234\211\345\276\205\345\244\204\347\220\206\347\232\204\344\277\241\346\201\257\350\256\260\345\275\225\345\210\260\347\224\237\350\202\211\345\272\223\344\270\255\357\274\214\351\201\277\345\205\215\351\201\227\346\274\217\357\274\214\345\220\214\346\227\266\350\257\245\350\275\257\344\273\266\350\277\230\346\217\220\344\276\233\344\272\206\344\273\273\345\212\241\346\217\220\351\206\222\345\212\237\350\203\275\357\274\214\344\277\235\350\257\201\347\224\250\346\210\267\344\270\215\344\274\232\351\224\231\350\277\207\344\273\273\344\275\225\351\207\215\350\246\201"
                        "\344\273\273\345\212\241\343\200\202\351\231\244\346\255\244\344\271\213\345\244\226\357\274\214\350\257\245\350\275\257\344\273\266\350\277\230\346\224\257\346\214\201\344\273\273\345\212\241\345\210\206\347\261\273\357\274\214\350\256\251\347\224\250\346\210\267\345\217\257\344\273\245\346\214\211\347\205\247\345\267\245\344\275\234\351\241\271\347\233\256\343\200\201\346\210\252\346\255\242\346\227\245\346\234\237\343\200\201\344\274\230\345\205\210\347\272\247\347\255\211\344\277\241\346\201\257\350\277\233\350\241\214\345\210\206\347\261\273\357\274\214\346\233\264\345\245\275\345\234\260\347\256\241\347\220\206\345\222\214\350\267\237\350\270\252\344\273\273\345\212\241\346\211\247\350\241\214\346\203\205\345\206\265\343\200\202\346\255\244\345\244\226\357\274\214\350\257\245\350\275\257\344\273\266\350\277\230\346\224\257\346\214\201\344\273\273\345\212\241\346\250\241\346\235\277\345\212\237\350\203\275\357\274\214\350\256\251\347\224\250\346\210\267\345\217\257\344\273\245\351\222\210\345\257\271\351\207"
                        "\215\345\244\215\346\200\247\344\273\273\345\212\241\357\274\214\345\277\253\351\200\237\345\210\233\345\273\272\346\226\260\344\273\273\345\212\241\357\274\214\346\217\220\351\253\230\344\272\206\345\267\245\344\275\234\346\225\210\347\216\207\343\200\202</p><p>GTDO\345\276\205\345\212\236\344\270\223\345\256\266\346\230\257\344\270\200\346\254\276\351\235\236\345\270\270\345\256\236\347\224\250\347\232\204\344\273\273\345\212\241\347\256\241\347\220\206\350\275\257\344\273\266\357\274\214\345\256\203\345\217\257\344\273\245\345\270\256\345\212\251\347\224\250\346\210\267\351\253\230\346\225\210\345\234\260\347\256\241\347\220\206\344\273\273\345\212\241\357\274\214\345\271\266\344\270\224\346\213\245\346\234\211\345\274\272\345\244\247\347\232\204\344\273\273\345\212\241\346\217\220\351\206\222\343\200\201\344\273\273\345\212\241\345\210\206\347\261\273\343\200\201\344\273\273\345\212\241\346\250\241\346\235\277\347\255\211\345\212\237\350\203\275\357\274\214\346\236\201\345\244\247\345\234\260\346\217\220\351"
                        "\253\230\344\272\206\345\267\245\344\275\234\346\225\210\347\216\207\345\222\214\347\224\237\346\264\273\345\223\201\350\264\250\343\200\202</p><p><br/></p><p>@2023 GTDO\345\276\205\345\212\236\344\270\223\345\256\266  \347\211\210\346\235\203\346\211\200\346\234\211</p></body></html>", nullptr));
        pushButton_3->setText(QCoreApplication::translate("GToDo", "\345\234\250\347\272\277\345\215\207\347\272\247", nullptr));
        lbGroup->setText(QCoreApplication::translate("GToDo", "\345\205\250\351\203\250\345\276\205\345\212\236", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_menu->setToolTip(QCoreApplication::translate("GToDo", "\350\217\234\345\215\225", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_menu->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_min->setToolTip(QCoreApplication::translate("GToDo", "\347\274\251\345\260\217\347\252\227\345\217\243\345\210\260\344\273\273\345\212\241\346\240\217", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_min->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_exit->setToolTip(QCoreApplication::translate("GToDo", "\345\205\263\351\227\255", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_exit->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_login->setToolTip(QCoreApplication::translate("GToDo", "\347\202\271\345\207\273\345\217\257\350\267\263\350\275\254\346\263\250\345\206\214\347\231\273\345\275\225", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_login->setText(QString());
#if QT_CONFIG(tooltip)
        sexuality->setToolTip(QCoreApplication::translate("GToDo", "\346\200\247\345\210\253\345\233\276\346\240\207\357\274\214\350\223\235\350\211\262\346\230\257\347\224\267\346\200\247\357\274\214\347\264\253\350\211\262\346\230\257\345\245\263\346\200\247\357\274\214\351\273\221\350\211\262\346\230\257\346\234\252\347\237\245\346\200\247\345\210\253\343\200\202", nullptr));
#endif // QT_CONFIG(tooltip)
        sexuality->setText(QString());
        label_userName->setText(QCoreApplication::translate("GToDo", "\345\227\250\357\274\201\350\257\267\347\231\273\345\275\225\357\274\201", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_login_img->setToolTip(QCoreApplication::translate("GToDo", "\347\202\271\345\207\273\345\217\257\350\267\263\350\275\254\344\270\252\344\272\272\344\270\255\345\277\203", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_login_img->setText(QString());
#if QT_CONFIG(tooltip)
        editAddGroup->setToolTip(QCoreApplication::translate("GToDo", "\346\267\273\345\212\240\346\226\260\347\273\204\357\274\214\345\234\250\350\276\223\345\205\245\346\241\206\350\276\223\345\205\245\346\226\260\347\247\237\345\220\215\345\233\236\350\275\246\351\224\256\347\241\256\350\256\244\346\267\273\345\212\240\345\215\263\345\217\257\346\267\273\345\212\240\343\200\202", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        editAddGroup->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        editAddGroup->setPlaceholderText(QCoreApplication::translate("GToDo", "\346\267\273\345\212\240\346\226\260\347\273\204\357\274\214\345\234\250\350\276\223\345\205\245\346\241\206\350\276\223\345\205\245\346\226\260\347\247\237\345\220\215\345\233\236\350\275\246\351\224\256\347\241\256\350\256\244\346\267\273\345\212\240\345\215\263\345\217\257\346\267\273\345\212\240\343\200\202", nullptr));
#if QT_CONFIG(tooltip)
        btnMyTask->setToolTip(QCoreApplication::translate("GToDo", "\345\205\250\351\203\250\345\210\206\347\273\204", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        btnMyTask->setStatusTip(QCoreApplication::translate("GToDo", "\345\205\250\351\203\250\345\210\206\347\273\204", nullptr));
#endif // QT_CONFIG(statustip)
        btnMyTask->setText(QCoreApplication::translate("GToDo", "\345\205\250\351\203\250", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GToDo: public Ui_GToDo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GTODO_H
