/****************************************************************************
** Meta object code from reading C++ file 'GToDo.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Code/GToDo.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GToDo.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GToDo_t {
    QByteArrayData data[55];
    char stringdata0[1260];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GToDo_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GToDo_t qt_meta_stringdata_GToDo = {
    {
QT_MOC_LITERAL(0, 0, 5), // "GToDo"
QT_MOC_LITERAL(1, 6, 21), // "on_btnRefresh_clicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 16), // "openSettingPanel"
QT_MOC_LITERAL(4, 46, 5), // "Title"
QT_MOC_LITERAL(5, 52, 8), // "Deadline"
QT_MOC_LITERAL(6, 61, 11), // "groupSwitch"
QT_MOC_LITERAL(7, 73, 5), // "group"
QT_MOC_LITERAL(8, 79, 28), // "on_editTitle_editingFinished"
QT_MOC_LITERAL(9, 108, 20), // "on_btnDetail_clicked"
QT_MOC_LITERAL(10, 129, 34), // "on_boxPriority_currentIndexCh..."
QT_MOC_LITERAL(11, 164, 5), // "index"
QT_MOC_LITERAL(12, 170, 32), // "on_boxRepeat_currentIndexChanged"
QT_MOC_LITERAL(13, 203, 30), // "on_Crontab_currentIndexChanged"
QT_MOC_LITERAL(14, 234, 20), // "on_btnSetDdl_clicked"
QT_MOC_LITERAL(15, 255, 23), // "on_btnSetRemind_clicked"
QT_MOC_LITERAL(16, 279, 20), // "on_btnMyTask_clicked"
QT_MOC_LITERAL(17, 300, 31), // "on_editAddGroup_editingFinished"
QT_MOC_LITERAL(18, 332, 30), // "on_editAddItem_editingFinished"
QT_MOC_LITERAL(19, 363, 31), // "on_boxOrder_currentIndexChanged"
QT_MOC_LITERAL(20, 395, 38), // "on_pushButton_background_colo..."
QT_MOC_LITERAL(21, 434, 27), // "on_pushButton_color_clicked"
QT_MOC_LITERAL(22, 462, 30), // "on_pushButton_textbold_clicked"
QT_MOC_LITERAL(23, 493, 32), // "on_pushButton_textitalic_clicked"
QT_MOC_LITERAL(24, 526, 31), // "on_pushButton_textunder_clicked"
QT_MOC_LITERAL(25, 558, 31), // "on_pushButton_textright_clicked"
QT_MOC_LITERAL(26, 590, 30), // "on_pushButton_textleft_clicked"
QT_MOC_LITERAL(27, 621, 33), // "on_pushButton_textjustify_cli..."
QT_MOC_LITERAL(28, 655, 32), // "on_pushButton_textcenter_clicked"
QT_MOC_LITERAL(29, 688, 21), // "on_comboBox_activated"
QT_MOC_LITERAL(30, 710, 4), // "arg1"
QT_MOC_LITERAL(31, 715, 26), // "on_pushButton_exit_clicked"
QT_MOC_LITERAL(32, 742, 27), // "on_pushButton_login_clicked"
QT_MOC_LITERAL(33, 770, 25), // "on_pushButton_min_clicked"
QT_MOC_LITERAL(34, 796, 26), // "on_pushButton_menu_clicked"
QT_MOC_LITERAL(35, 823, 31), // "on_pushButton_login_img_clicked"
QT_MOC_LITERAL(36, 855, 15), // "mousePressEvent"
QT_MOC_LITERAL(37, 871, 12), // "QMouseEvent*"
QT_MOC_LITERAL(38, 884, 5), // "event"
QT_MOC_LITERAL(39, 890, 14), // "mouseMoveEvent"
QT_MOC_LITERAL(40, 905, 17), // "mouseReleaseEvent"
QT_MOC_LITERAL(41, 923, 25), // "on_pushButton_reg_clicked"
QT_MOC_LITERAL(42, 949, 31), // "on_pushButton_longinbtn_clicked"
QT_MOC_LITERAL(43, 981, 28), // "on_pushButton_regbtn_clicked"
QT_MOC_LITERAL(44, 1010, 21), // "on_btn_signin_clicked"
QT_MOC_LITERAL(45, 1032, 23), // "on_selectButton_clicked"
QT_MOC_LITERAL(46, 1056, 21), // "on_saveButton_clicked"
QT_MOC_LITERAL(47, 1078, 26), // "on_QPushButton_out_clicked"
QT_MOC_LITERAL(48, 1105, 13), // "iconActivated"
QT_MOC_LITERAL(49, 1119, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(50, 1153, 6), // "reason"
QT_MOC_LITERAL(51, 1160, 21), // "on_update_img_clicked"
QT_MOC_LITERAL(52, 1182, 20), // "on_Clear_btn_clicked"
QT_MOC_LITERAL(53, 1203, 26), // "on_Selection_Audio_clicked"
QT_MOC_LITERAL(54, 1230, 29) // "on_Selection_Audio_ok_clicked"

    },
    "GToDo\0on_btnRefresh_clicked\0\0"
    "openSettingPanel\0Title\0Deadline\0"
    "groupSwitch\0group\0on_editTitle_editingFinished\0"
    "on_btnDetail_clicked\0"
    "on_boxPriority_currentIndexChanged\0"
    "index\0on_boxRepeat_currentIndexChanged\0"
    "on_Crontab_currentIndexChanged\0"
    "on_btnSetDdl_clicked\0on_btnSetRemind_clicked\0"
    "on_btnMyTask_clicked\0"
    "on_editAddGroup_editingFinished\0"
    "on_editAddItem_editingFinished\0"
    "on_boxOrder_currentIndexChanged\0"
    "on_pushButton_background_color_clicked\0"
    "on_pushButton_color_clicked\0"
    "on_pushButton_textbold_clicked\0"
    "on_pushButton_textitalic_clicked\0"
    "on_pushButton_textunder_clicked\0"
    "on_pushButton_textright_clicked\0"
    "on_pushButton_textleft_clicked\0"
    "on_pushButton_textjustify_clicked\0"
    "on_pushButton_textcenter_clicked\0"
    "on_comboBox_activated\0arg1\0"
    "on_pushButton_exit_clicked\0"
    "on_pushButton_login_clicked\0"
    "on_pushButton_min_clicked\0"
    "on_pushButton_menu_clicked\0"
    "on_pushButton_login_img_clicked\0"
    "mousePressEvent\0QMouseEvent*\0event\0"
    "mouseMoveEvent\0mouseReleaseEvent\0"
    "on_pushButton_reg_clicked\0"
    "on_pushButton_longinbtn_clicked\0"
    "on_pushButton_regbtn_clicked\0"
    "on_btn_signin_clicked\0on_selectButton_clicked\0"
    "on_saveButton_clicked\0on_QPushButton_out_clicked\0"
    "iconActivated\0QSystemTrayIcon::ActivationReason\0"
    "reason\0on_update_img_clicked\0"
    "on_Clear_btn_clicked\0on_Selection_Audio_clicked\0"
    "on_Selection_Audio_ok_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GToDo[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      45,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  239,    2, 0x08 /* Private */,
       3,    2,  240,    2, 0x08 /* Private */,
       6,    1,  245,    2, 0x08 /* Private */,
       8,    0,  248,    2, 0x08 /* Private */,
       9,    0,  249,    2, 0x08 /* Private */,
      10,    1,  250,    2, 0x08 /* Private */,
      12,    1,  253,    2, 0x08 /* Private */,
      13,    1,  256,    2, 0x08 /* Private */,
      14,    0,  259,    2, 0x08 /* Private */,
      15,    0,  260,    2, 0x08 /* Private */,
      16,    0,  261,    2, 0x08 /* Private */,
      17,    0,  262,    2, 0x08 /* Private */,
      18,    0,  263,    2, 0x08 /* Private */,
      19,    1,  264,    2, 0x08 /* Private */,
      20,    0,  267,    2, 0x08 /* Private */,
      21,    0,  268,    2, 0x08 /* Private */,
      22,    0,  269,    2, 0x08 /* Private */,
      23,    0,  270,    2, 0x08 /* Private */,
      24,    0,  271,    2, 0x08 /* Private */,
      25,    0,  272,    2, 0x08 /* Private */,
      26,    0,  273,    2, 0x08 /* Private */,
      27,    0,  274,    2, 0x08 /* Private */,
      28,    0,  275,    2, 0x08 /* Private */,
      29,    1,  276,    2, 0x08 /* Private */,
      29,    1,  279,    2, 0x08 /* Private */,
      31,    0,  282,    2, 0x08 /* Private */,
      32,    0,  283,    2, 0x08 /* Private */,
      33,    0,  284,    2, 0x08 /* Private */,
      34,    0,  285,    2, 0x08 /* Private */,
      35,    0,  286,    2, 0x08 /* Private */,
      36,    1,  287,    2, 0x08 /* Private */,
      39,    1,  290,    2, 0x08 /* Private */,
      40,    1,  293,    2, 0x08 /* Private */,
      41,    0,  296,    2, 0x08 /* Private */,
      42,    0,  297,    2, 0x08 /* Private */,
      43,    0,  298,    2, 0x08 /* Private */,
      44,    0,  299,    2, 0x08 /* Private */,
      45,    0,  300,    2, 0x08 /* Private */,
      46,    0,  301,    2, 0x08 /* Private */,
      47,    0,  302,    2, 0x08 /* Private */,
      48,    1,  303,    2, 0x08 /* Private */,
      51,    0,  306,    2, 0x08 /* Private */,
      52,    0,  307,    2, 0x08 /* Private */,
      53,    0,  308,    2, 0x08 /* Private */,
      54,    0,  309,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    4,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,   30,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 37,   38,
    QMetaType::Void, 0x80000000 | 37,   38,
    QMetaType::Void, 0x80000000 | 37,   38,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 49,   50,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GToDo::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GToDo *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btnRefresh_clicked(); break;
        case 1: _t->openSettingPanel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->groupSwitch((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->on_editTitle_editingFinished(); break;
        case 4: _t->on_btnDetail_clicked(); break;
        case 5: _t->on_boxPriority_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_boxRepeat_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_Crontab_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_btnSetDdl_clicked(); break;
        case 9: _t->on_btnSetRemind_clicked(); break;
        case 10: _t->on_btnMyTask_clicked(); break;
        case 11: _t->on_editAddGroup_editingFinished(); break;
        case 12: _t->on_editAddItem_editingFinished(); break;
        case 13: _t->on_boxOrder_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_pushButton_background_color_clicked(); break;
        case 15: _t->on_pushButton_color_clicked(); break;
        case 16: _t->on_pushButton_textbold_clicked(); break;
        case 17: _t->on_pushButton_textitalic_clicked(); break;
        case 18: _t->on_pushButton_textunder_clicked(); break;
        case 19: _t->on_pushButton_textright_clicked(); break;
        case 20: _t->on_pushButton_textleft_clicked(); break;
        case 21: _t->on_pushButton_textjustify_clicked(); break;
        case 22: _t->on_pushButton_textcenter_clicked(); break;
        case 23: _t->on_comboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_comboBox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 25: _t->on_pushButton_exit_clicked(); break;
        case 26: _t->on_pushButton_login_clicked(); break;
        case 27: _t->on_pushButton_min_clicked(); break;
        case 28: _t->on_pushButton_menu_clicked(); break;
        case 29: _t->on_pushButton_login_img_clicked(); break;
        case 30: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 31: _t->mouseMoveEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 32: _t->mouseReleaseEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 33: _t->on_pushButton_reg_clicked(); break;
        case 34: _t->on_pushButton_longinbtn_clicked(); break;
        case 35: _t->on_pushButton_regbtn_clicked(); break;
        case 36: _t->on_btn_signin_clicked(); break;
        case 37: _t->on_selectButton_clicked(); break;
        case 38: _t->on_saveButton_clicked(); break;
        case 39: _t->on_QPushButton_out_clicked(); break;
        case 40: _t->iconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 41: _t->on_update_img_clicked(); break;
        case 42: _t->on_Clear_btn_clicked(); break;
        case 43: _t->on_Selection_Audio_clicked(); break;
        case 44: _t->on_Selection_Audio_ok_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GToDo::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_GToDo.data,
    qt_meta_data_GToDo,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GToDo::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GToDo::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GToDo.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GToDo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 45)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 45;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 45)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 45;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
