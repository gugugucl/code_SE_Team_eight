/****************************************************************************
** Meta object code from reading C++ file 'GToDo.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Code/GToDo.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GToDo.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GToDo_t {
    QByteArrayData data[58];
    char stringdata0[1290];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GToDo_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GToDo_t qt_meta_stringdata_GToDo = {
    {
QT_MOC_LITERAL(0, 0, 5), // "GToDo"
QT_MOC_LITERAL(1, 6, 7), // "myclock"
QT_MOC_LITERAL(2, 14, 0), // ""
QT_MOC_LITERAL(3, 15, 19), // "onRiliButtonClicked"
QT_MOC_LITERAL(4, 35, 5), // "smart"
QT_MOC_LITERAL(5, 41, 16), // "openSettingPanel"
QT_MOC_LITERAL(6, 58, 5), // "Title"
QT_MOC_LITERAL(7, 64, 8), // "Deadline"
QT_MOC_LITERAL(8, 73, 11), // "groupSwitch"
QT_MOC_LITERAL(9, 85, 5), // "group"
QT_MOC_LITERAL(10, 91, 28), // "on_editTitle_editingFinished"
QT_MOC_LITERAL(11, 120, 20), // "on_btnDetail_clicked"
QT_MOC_LITERAL(12, 141, 34), // "on_boxPriority_currentIndexCh..."
QT_MOC_LITERAL(13, 176, 5), // "index"
QT_MOC_LITERAL(14, 182, 32), // "on_boxRepeat_currentIndexChanged"
QT_MOC_LITERAL(15, 215, 30), // "on_Crontab_currentIndexChanged"
QT_MOC_LITERAL(16, 246, 20), // "on_btnSetDdl_clicked"
QT_MOC_LITERAL(17, 267, 23), // "on_btnSetRemind_clicked"
QT_MOC_LITERAL(18, 291, 20), // "on_btnMyTask_clicked"
QT_MOC_LITERAL(19, 312, 31), // "on_editAddGroup_editingFinished"
QT_MOC_LITERAL(20, 344, 30), // "on_editAddItem_editingFinished"
QT_MOC_LITERAL(21, 375, 31), // "on_boxOrder_currentIndexChanged"
QT_MOC_LITERAL(22, 407, 38), // "on_pushButton_background_colo..."
QT_MOC_LITERAL(23, 446, 27), // "on_pushButton_color_clicked"
QT_MOC_LITERAL(24, 474, 30), // "on_pushButton_textbold_clicked"
QT_MOC_LITERAL(25, 505, 32), // "on_pushButton_textitalic_clicked"
QT_MOC_LITERAL(26, 538, 31), // "on_pushButton_textunder_clicked"
QT_MOC_LITERAL(27, 570, 31), // "on_pushButton_textright_clicked"
QT_MOC_LITERAL(28, 602, 30), // "on_pushButton_textleft_clicked"
QT_MOC_LITERAL(29, 633, 33), // "on_pushButton_textjustify_cli..."
QT_MOC_LITERAL(30, 667, 32), // "on_pushButton_textcenter_clicked"
QT_MOC_LITERAL(31, 700, 21), // "on_comboBox_activated"
QT_MOC_LITERAL(32, 722, 4), // "arg1"
QT_MOC_LITERAL(33, 727, 26), // "on_pushButton_exit_clicked"
QT_MOC_LITERAL(34, 754, 27), // "on_pushButton_login_clicked"
QT_MOC_LITERAL(35, 782, 25), // "on_pushButton_min_clicked"
QT_MOC_LITERAL(36, 808, 26), // "on_pushButton_menu_clicked"
QT_MOC_LITERAL(37, 835, 31), // "on_pushButton_login_img_clicked"
QT_MOC_LITERAL(38, 867, 15), // "mousePressEvent"
QT_MOC_LITERAL(39, 883, 12), // "QMouseEvent*"
QT_MOC_LITERAL(40, 896, 5), // "event"
QT_MOC_LITERAL(41, 902, 14), // "mouseMoveEvent"
QT_MOC_LITERAL(42, 917, 17), // "mouseReleaseEvent"
QT_MOC_LITERAL(43, 935, 25), // "on_pushButton_reg_clicked"
QT_MOC_LITERAL(44, 961, 31), // "on_pushButton_longinbtn_clicked"
QT_MOC_LITERAL(45, 993, 28), // "on_pushButton_regbtn_clicked"
QT_MOC_LITERAL(46, 1022, 21), // "on_btn_signin_clicked"
QT_MOC_LITERAL(47, 1044, 23), // "on_selectButton_clicked"
QT_MOC_LITERAL(48, 1068, 21), // "on_saveButton_clicked"
QT_MOC_LITERAL(49, 1090, 26), // "on_QPushButton_out_clicked"
QT_MOC_LITERAL(50, 1117, 13), // "iconActivated"
QT_MOC_LITERAL(51, 1131, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(52, 1165, 6), // "reason"
QT_MOC_LITERAL(53, 1172, 21), // "on_update_img_clicked"
QT_MOC_LITERAL(54, 1194, 20), // "on_Clear_btn_clicked"
QT_MOC_LITERAL(55, 1215, 26), // "on_Selection_Audio_clicked"
QT_MOC_LITERAL(56, 1242, 29), // "on_Selection_Audio_ok_clicked"
QT_MOC_LITERAL(57, 1272, 17) // "on_Dialog_clicked"

    },
    "GToDo\0myclock\0\0onRiliButtonClicked\0"
    "smart\0openSettingPanel\0Title\0Deadline\0"
    "groupSwitch\0group\0on_editTitle_editingFinished\0"
    "on_btnDetail_clicked\0"
    "on_boxPriority_currentIndexChanged\0"
    "index\0on_boxRepeat_currentIndexChanged\0"
    "on_Crontab_currentIndexChanged\0"
    "on_btnSetDdl_clicked\0on_btnSetRemind_clicked\0"
    "on_btnMyTask_clicked\0"
    "on_editAddGroup_editingFinished\0"
    "on_editAddItem_editingFinished\0"
    "on_boxOrder_currentIndexChanged\0"
    "on_pushButton_background_color_clicked\0"
    "on_pushButton_color_clicked\0"
    "on_pushButton_textbold_clicked\0"
    "on_pushButton_textitalic_clicked\0"
    "on_pushButton_textunder_clicked\0"
    "on_pushButton_textright_clicked\0"
    "on_pushButton_textleft_clicked\0"
    "on_pushButton_textjustify_clicked\0"
    "on_pushButton_textcenter_clicked\0"
    "on_comboBox_activated\0arg1\0"
    "on_pushButton_exit_clicked\0"
    "on_pushButton_login_clicked\0"
    "on_pushButton_min_clicked\0"
    "on_pushButton_menu_clicked\0"
    "on_pushButton_login_img_clicked\0"
    "mousePressEvent\0QMouseEvent*\0event\0"
    "mouseMoveEvent\0mouseReleaseEvent\0"
    "on_pushButton_reg_clicked\0"
    "on_pushButton_longinbtn_clicked\0"
    "on_pushButton_regbtn_clicked\0"
    "on_btn_signin_clicked\0on_selectButton_clicked\0"
    "on_saveButton_clicked\0on_QPushButton_out_clicked\0"
    "iconActivated\0QSystemTrayIcon::ActivationReason\0"
    "reason\0on_update_img_clicked\0"
    "on_Clear_btn_clicked\0on_Selection_Audio_clicked\0"
    "on_Selection_Audio_ok_clicked\0"
    "on_Dialog_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GToDo[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      48,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  254,    2, 0x08 /* Private */,
       3,    0,  255,    2, 0x08 /* Private */,
       4,    0,  256,    2, 0x08 /* Private */,
       5,    2,  257,    2, 0x08 /* Private */,
       8,    1,  262,    2, 0x08 /* Private */,
      10,    0,  265,    2, 0x08 /* Private */,
      11,    0,  266,    2, 0x08 /* Private */,
      12,    1,  267,    2, 0x08 /* Private */,
      14,    1,  270,    2, 0x08 /* Private */,
      15,    1,  273,    2, 0x08 /* Private */,
      16,    0,  276,    2, 0x08 /* Private */,
      17,    0,  277,    2, 0x08 /* Private */,
      18,    0,  278,    2, 0x08 /* Private */,
      19,    0,  279,    2, 0x08 /* Private */,
      20,    0,  280,    2, 0x08 /* Private */,
      21,    1,  281,    2, 0x08 /* Private */,
      22,    0,  284,    2, 0x08 /* Private */,
      23,    0,  285,    2, 0x08 /* Private */,
      24,    0,  286,    2, 0x08 /* Private */,
      25,    0,  287,    2, 0x08 /* Private */,
      26,    0,  288,    2, 0x08 /* Private */,
      27,    0,  289,    2, 0x08 /* Private */,
      28,    0,  290,    2, 0x08 /* Private */,
      29,    0,  291,    2, 0x08 /* Private */,
      30,    0,  292,    2, 0x08 /* Private */,
      31,    1,  293,    2, 0x08 /* Private */,
      31,    1,  296,    2, 0x08 /* Private */,
      33,    0,  299,    2, 0x08 /* Private */,
      34,    0,  300,    2, 0x08 /* Private */,
      35,    0,  301,    2, 0x08 /* Private */,
      36,    0,  302,    2, 0x08 /* Private */,
      37,    0,  303,    2, 0x08 /* Private */,
      38,    1,  304,    2, 0x08 /* Private */,
      41,    1,  307,    2, 0x08 /* Private */,
      42,    1,  310,    2, 0x08 /* Private */,
      43,    0,  313,    2, 0x08 /* Private */,
      44,    0,  314,    2, 0x08 /* Private */,
      45,    0,  315,    2, 0x08 /* Private */,
      46,    0,  316,    2, 0x08 /* Private */,
      47,    0,  317,    2, 0x08 /* Private */,
      48,    0,  318,    2, 0x08 /* Private */,
      49,    0,  319,    2, 0x08 /* Private */,
      50,    1,  320,    2, 0x08 /* Private */,
      53,    0,  323,    2, 0x08 /* Private */,
      54,    0,  324,    2, 0x08 /* Private */,
      55,    0,  325,    2, 0x08 /* Private */,
      56,    0,  326,    2, 0x08 /* Private */,
      57,    0,  327,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    6,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void, 0x80000000 | 39,   40,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 51,   52,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GToDo::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GToDo *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->myclock(); break;
        case 1: _t->onRiliButtonClicked(); break;
        case 2: _t->smart(); break;
        case 3: _t->openSettingPanel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 4: _t->groupSwitch((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->on_editTitle_editingFinished(); break;
        case 6: _t->on_btnDetail_clicked(); break;
        case 7: _t->on_boxPriority_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_boxRepeat_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_Crontab_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_btnSetDdl_clicked(); break;
        case 11: _t->on_btnSetRemind_clicked(); break;
        case 12: _t->on_btnMyTask_clicked(); break;
        case 13: _t->on_editAddGroup_editingFinished(); break;
        case 14: _t->on_editAddItem_editingFinished(); break;
        case 15: _t->on_boxOrder_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_pushButton_background_color_clicked(); break;
        case 17: _t->on_pushButton_color_clicked(); break;
        case 18: _t->on_pushButton_textbold_clicked(); break;
        case 19: _t->on_pushButton_textitalic_clicked(); break;
        case 20: _t->on_pushButton_textunder_clicked(); break;
        case 21: _t->on_pushButton_textright_clicked(); break;
        case 22: _t->on_pushButton_textleft_clicked(); break;
        case 23: _t->on_pushButton_textjustify_clicked(); break;
        case 24: _t->on_pushButton_textcenter_clicked(); break;
        case 25: _t->on_comboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_comboBox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 27: _t->on_pushButton_exit_clicked(); break;
        case 28: _t->on_pushButton_login_clicked(); break;
        case 29: _t->on_pushButton_min_clicked(); break;
        case 30: _t->on_pushButton_menu_clicked(); break;
        case 31: _t->on_pushButton_login_img_clicked(); break;
        case 32: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 33: _t->mouseMoveEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 34: _t->mouseReleaseEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 35: _t->on_pushButton_reg_clicked(); break;
        case 36: _t->on_pushButton_longinbtn_clicked(); break;
        case 37: _t->on_pushButton_regbtn_clicked(); break;
        case 38: _t->on_btn_signin_clicked(); break;
        case 39: _t->on_selectButton_clicked(); break;
        case 40: _t->on_saveButton_clicked(); break;
        case 41: _t->on_QPushButton_out_clicked(); break;
        case 42: _t->iconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 43: _t->on_update_img_clicked(); break;
        case 44: _t->on_Clear_btn_clicked(); break;
        case 45: _t->on_Selection_Audio_clicked(); break;
        case 46: _t->on_Selection_Audio_ok_clicked(); break;
        case 47: _t->on_Dialog_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GToDo::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_GToDo.data,
    qt_meta_data_GToDo,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GToDo::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GToDo::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GToDo.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GToDo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 48)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 48;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 48)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 48;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
