/****************************************************************************
** Meta object code from reading C++ file 'page_mini.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Code/page_mini.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'page_mini.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PageMini_t {
    QByteArrayData data[12];
    char stringdata0[215];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PageMini_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PageMini_t qt_meta_stringdata_PageMini = {
    {
QT_MOC_LITERAL(0, 0, 8), // "PageMini"
QT_MOC_LITERAL(1, 9, 17), // "signal_close_mini"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 17), // "signal_start_work"
QT_MOC_LITERAL(4, 46, 17), // "signal_start_rest"
QT_MOC_LITERAL(5, 64, 17), // "slot_update_timer"
QT_MOC_LITERAL(6, 82, 10), // "time_stamp"
QT_MOC_LITERAL(7, 93, 10), // "show_point"
QT_MOC_LITERAL(8, 104, 28), // "on_pushButton_normal_clicked"
QT_MOC_LITERAL(9, 133, 26), // "on_pushButton_work_clicked"
QT_MOC_LITERAL(10, 160, 26), // "on_pushButton_rest_clicked"
QT_MOC_LITERAL(11, 187, 27) // "on_pushButton_close_clicked"

    },
    "PageMini\0signal_close_mini\0\0"
    "signal_start_work\0signal_start_rest\0"
    "slot_update_timer\0time_stamp\0show_point\0"
    "on_pushButton_normal_clicked\0"
    "on_pushButton_work_clicked\0"
    "on_pushButton_rest_clicked\0"
    "on_pushButton_close_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PageMini[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   54,    2, 0x06 /* Public */,
       3,    0,   55,    2, 0x06 /* Public */,
       4,    0,   56,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    2,   57,    2, 0x08 /* Private */,
       8,    0,   62,    2, 0x08 /* Private */,
       9,    0,   63,    2, 0x08 /* Private */,
      10,    0,   64,    2, 0x08 /* Private */,
      11,    0,   65,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PageMini::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PageMini *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signal_close_mini(); break;
        case 1: _t->signal_start_work(); break;
        case 2: _t->signal_start_rest(); break;
        case 3: _t->slot_update_timer((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 4: _t->on_pushButton_normal_clicked(); break;
        case 5: _t->on_pushButton_work_clicked(); break;
        case 6: _t->on_pushButton_rest_clicked(); break;
        case 7: _t->on_pushButton_close_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PageMini::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageMini::signal_close_mini)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PageMini::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageMini::signal_start_work)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PageMini::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageMini::signal_start_rest)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PageMini::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_PageMini.data,
    qt_meta_data_PageMini,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PageMini::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PageMini::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PageMini.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int PageMini::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void PageMini::signal_close_mini()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void PageMini::signal_start_work()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void PageMini::signal_start_rest()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
