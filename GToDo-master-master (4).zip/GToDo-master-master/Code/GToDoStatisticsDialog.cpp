#include "GToDoStatisticsDialog.h"
#include <QtCharts>
#include <QVBoxLayout>
#include <QSqlQuery>
#include <QScrollArea>
#include <QLabel>
using namespace QtCharts;

GToDoStatisticsDialog::GToDoStatisticsDialog(QWidget *parent)
    : QDialog(parent) {
    this->setWindowTitle("待办事项统计图");
    this->resize(700, 800);

    QScrollArea *scrollArea = new QScrollArea(this);
    QWidget *container = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(container);

    // --------- 1. 完成情况 ---------
    QPieSeries *finishSeries = new QPieSeries();
    QSqlQuery q;
    q.exec("SELECT COUNT(*) FROM todolist WHERE Finished = 1");
    q.next();
    finishSeries->append("已完成", q.value(0).toInt());

    q.exec("SELECT COUNT(*) FROM todolist WHERE Finished = 0");
    q.next();
    finishSeries->append("未完成", q.value(0).toInt());

    QChart *finishChart = new QChart();
    finishChart->addSeries(finishSeries);
    finishChart->setTitle("任务完成情况");

    layout->addWidget(new QChartView(finishChart));

    // --------- 2. 优先级分布 ---------
    QBarSeries *prioritySeries = new QBarSeries();
    QBarSet *set = new QBarSet("任务数量");

    QStringList levels = {"普通", "低", "中", "高"};
    int maxValue = 0;

    for (int i = 0; i < 4; ++i) {
        // 包括已完成任务
        q.exec(QString("SELECT COUNT(*) FROM todolist WHERE Priority = %1").arg(i));
        q.next();
        int count = q.value(0).toInt();
        *set << count;
        maxValue = qMax(maxValue, count);
    }

    prioritySeries->append(set);

    // ✅ 显示标签（这一步才对）
    prioritySeries->setLabelsVisible(true);
    prioritySeries->setLabelsPosition(QAbstractBarSeries::LabelsInsideEnd);
    prioritySeries->setLabelsFormat("@value");  // 显示值

    QChart *priorityChart = new QChart();
    priorityChart->addSeries(prioritySeries);
    priorityChart->setTitle("任务优先级分布");

    // 设置 X 轴
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(levels);
    priorityChart->addAxis(axisX, Qt::AlignBottom);
    prioritySeries->attachAxis(axisX);

    // 设置 Y 轴
    QValueAxis *axisY = new QValueAxis();
    axisY->setLabelFormat("%d");         // 整数格式
    axisY->setTickCount(maxValue + 2);   // 设置刻度
    axisY->setMin(0);
    axisY->setMax(maxValue + 1);
    priorityChart->addAxis(axisY, Qt::AlignLeft);
    prioritySeries->attachAxis(axisY);

    // 显示图表
    layout->addWidget(new QChartView(priorityChart));


    // --------- 3. 按日期分布（未来7天） ---------
    QLineSeries *deadlineSeries = new QLineSeries();
    QDate today = QDate::currentDate();

    // 确保每一天都有数据点，即使该天的任务数量为0
    for (int i = 0; i < 7; ++i) {
        QDate date = today.addDays(i);
        QString dateStr = date.toString("yyyy-MM-dd");
        q.exec(QString("SELECT COUNT(*) FROM todolist WHERE Deadline = '%1'").arg(dateStr));
        q.next();
        int taskCount = q.value(0).toInt();
        deadlineSeries->append(i, taskCount);  // 确保即使任务数为0也会显示该天
    }

    // 优化折线图
    QChart *deadlineChart = new QChart();
    deadlineChart->addSeries(deadlineSeries);
    deadlineChart->setTitle("未来7天任务数");

    // 优化 X 轴
    QCategoryAxis *xAxis = new QCategoryAxis();
    for (int i = 0; i < 7; ++i)
        xAxis->append(today.addDays(i).toString("MM-dd"), i);
    deadlineChart->addAxis(xAxis, Qt::AlignBottom);
    deadlineSeries->attachAxis(xAxis);

    // 优化 Y 轴
    QValueAxis *yAxis = new QValueAxis();
    yAxis->setLabelFormat("%d");
    yAxis->setMin(0);  // 设置 Y 轴最小值为0
    deadlineChart->addAxis(yAxis, Qt::AlignLeft);
    deadlineSeries->attachAxis(yAxis);

    // 优化折线样式
    deadlineSeries->setColor(QColor("#1f77b4"));  // 设置线条颜色
    deadlineSeries->setPointLabelsVisible(true);  // 显示每个点的标签
    deadlineSeries->setPointLabelsFormat("@yPoint"); // 标签格式

    layout->addWidget(new QChartView(deadlineChart));

    container->setLayout(layout);
    scrollArea->setWidget(container);
    scrollArea->setWidgetResizable(true);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(scrollArea);
}
