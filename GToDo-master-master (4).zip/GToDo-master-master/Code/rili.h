#ifndef RILI_H
#define RILI_H

#include <QWidget>
#include <QCalendarWidget>
#include <QMap>
#include <QStringList>
#include <QLabel>
#include <QSqlQuery>
#include <QSqlError>
#include <QPushButton>
#include <QSettings>
#include <QDate>

class Rili : public QWidget {
    Q_OBJECT
public:
    explicit Rili(QWidget *parent = nullptr);

private:
    QCalendarWidget *calendar;
    QLabel *backgroundLabel = nullptr;
    QMap<QDate, QStringList> tasksMap;

    void loadTasksFromDatabase();
    void highlightDates();
    void setCustomBackground();
    void loadBackground();  // 加载背景图
    bool backgroundLoaded = false;  // 用于避免多次加载背景
};

#endif // RILI_H
