#ifndef GTODOSTATISTICSDIALOG_H
#define GTODOSTATISTICSDIALOG_H

#include <QDialog>

class GToDoStatisticsDialog : public QDialog {
    Q_OBJECT
public:
    explicit GToDoStatisticsDialog(QWidget *parent = nullptr);
};

#endif // GTODOSTATISTICSDIALOG_H
