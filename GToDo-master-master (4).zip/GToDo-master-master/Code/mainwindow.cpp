#include "mainwindow.h"
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonParseError>
#include <QDebug>
#include<QCoreApplication>
#include<QSqlQuery>
#include<QDir>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    qDebug() << "Library paths:" << QCoreApplication::libraryPaths();
    // 使用 QDir 规范化路径
    QString opensslPath = QCoreApplication::applicationDirPath() + "/openssl";
    QDir opensslDir(opensslPath);
    if (!opensslDir.exists()) {
        qWarning() << "OpenSSL path does not exist:" << opensslPath;
    }
    QCoreApplication::addLibraryPath(opensslPath);
    // 检查 SSL 支持
    qDebug() << "SSL supported:" << QSslSocket::supportsSsl();
    qDebug() << "SSL build version:" << QSslSocket::sslLibraryBuildVersionString();
    qDebug() << "SSL runtime version:" << QSslSocket::sslLibraryVersionString();

    // 设置窗口大小
    this->setFixedSize(800, 600);

    // 创建主容器
    QWidget *centralWidget = new QWidget(this);
    this->setCentralWidget(centralWidget);

    // 创建布局
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // 创建聊天记录TextEdit
    chatTextEdit = new QTextEdit();
    chatTextEdit->setReadOnly(true);
    chatTextEdit->setPlaceholderText("聊天记录");
    mainLayout->addWidget(chatTextEdit);
    // 创建 AI 分析按钮（右上角小圆形按钮）
    evaluateButton = new QPushButton("🔍", this);
    evaluateButton->setFixedSize(40, 40);
    evaluateButton->setStyleSheet("border-radius: 20px; background-color: #0078D7; color: white; font-weight: bold;");
    evaluateButton->move(this->width() - 50, 10); // 距离右上角边缘

    // 绑定槽函数
    connect(evaluateButton, &QPushButton::clicked, this, &MainWindow::evaluateScheduleSlot);

    // 创建输入TextEdit
    inputTextEdit = new QTextEdit();
    inputTextEdit->setPlaceholderText("请输入您的问题");
    inputTextEdit->setFixedHeight(100);
    mainLayout->addWidget(inputTextEdit);

    // 创建按钮
    sendButton = new QPushButton("发送");
    mainLayout->addWidget(sendButton);

    // 初始化网络管理器
    networkManager = new QNetworkAccessManager(this);
    connect(networkManager, &QNetworkAccessManager::finished, this, &MainWindow::replyFinished);

    // 连接信号与槽
    connect(sendButton, &QPushButton::clicked, this, &MainWindow::clickedSlot);
    // 使用textChanged信号来检测回车
    connect(inputTextEdit, &QTextEdit::textChanged, this, [=]() {
        if (inputTextEdit->toPlainText().contains("\n")) {
            clickedSlot();
        }
    });

    // 初始化聊天记录
    chatTextEdit->append("欢迎使用DeepSeek AI助手！请输入您的问题。");
}

MainWindow::~MainWindow()
{
}

void MainWindow::clickedSlot()
{
    QString question = inputTextEdit->toPlainText().trimmed();
    if (question.isEmpty()) {
        return;
    }

    // 清空输入框
    inputTextEdit->clear();

    // 显示问题
    chatTextEdit->append("您：");
    chatTextEdit->append(question);
    chatTextEdit->append("\n");

    // 调用DeepSeek API
    QNetworkRequest request;
    request.setUrl(QUrl("https://api.deepseek.com/v1/chat/completions"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer sk-38236ed25d7341ebb2530bf10b818513");

    QJsonObject jsonPayload;
    jsonPayload["model"] = "deepseek-chat";
    QJsonArray messages;
    messages.append(QJsonObject{
        {"role", "user"},
        {"content", question}
    });
    jsonPayload["messages"] = messages;

    QJsonDocument doc(jsonPayload);
    QByteArray requestData = doc.toJson(QJsonDocument::JsonFormat::Indented);

    // 添加调试信息：打印请求内容
    qDebug() << "发送的请求内容：";
    qDebug() << "URL：" << request.url().toString();
    qDebug() << "请求头：";
    qDebug() << "Authorization：" << request.rawHeader("Authorization");
    qDebug() << "模型：" << jsonPayload.value("model").toString();
    qDebug() << "消息内容：";
    for (const QJsonValue &msg : messages) {
        QJsonObject msgObj = msg.toObject();
        qDebug() << "角色：" << msgObj.value("role").toString();
        qDebug() << "内容：" << msgObj.value("content").toString();
    }
    qDebug() << "请求数据：" << requestData;

    networkManager->post(request, requestData);
}

void MainWindow::replyFinished(QNetworkReply *reply)
{
    // 添加调试信息：打印响应状态
    qDebug() << "响应状态：";
    qDebug() << "HTTP状态码：" << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    qDebug() << "响应头：";
    qDebug() << reply->rawHeaderList();
    qDebug() << "响应内容：";
    QByteArray responseData = reply->readAll();
    qDebug() << responseData;

    if (reply->error() == QNetworkReply::NoError) {
        QJsonParseError parseError;
        QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

        if (parseError.error == QJsonParseError::NoError) {
            QJsonObject jsonObject = doc.object();
            QJsonArray choices = jsonObject.value("choices").toArray();

            for (const QJsonValue &choice : choices) {
                QJsonObject choiceObj = choice.toObject();
                if (choiceObj.contains("message")) {
                    QJsonObject messageObj = choiceObj.value("message").toObject();
                    if (messageObj.value("role").toString() == "assistant") {
                        if (messageObj.contains("content") && messageObj["content"].isString()) {
                            QString responseText = messageObj.value("content").toString();
                            // 处理可能的转义字符
                            responseText = QString::fromUtf8(responseText.toUtf8());
                            chatTextEdit->append("AI助手：");
                            chatTextEdit->append(responseText);
                            chatTextEdit->append("\n");
                        } else {
                            qDebug() << "内容字段缺失或类型不正确";
                            chatTextEdit->append("错误：内容字段缺失或类型不正确");
                        }
                    }
                }
            }
        } else {
            // 添加调试信息：打印解析错误
            qDebug() << "JSON解析错误：" << parseError.errorString();
            chatTextEdit->append("错误：JSON解析失败");
        }
    } else {
        // 添加调试信息：打印网络错误
        qDebug() << "网络错误：" << reply->errorString();
        chatTextEdit->append("错误：网络请求失败");
    }

    // 释放内存
    reply->deleteLater();
}
void MainWindow::evaluateScheduleSlot()
{
    // 从数据库中读取任务
    QSqlQuery query("SELECT Title, Deadline, Priority, Finished FROM todolist");
    QString taskSummary;

    while (query.next()) {
        QString title = query.value("Title").toString();
        QString deadline = query.value("Deadline").toString();
        int priority = query.value("Priority").toInt();
        bool finished = query.value("Finished").toBool();

        taskSummary += QString("任务: %1\n截止: %2\n优先级: %3\n已完成: %4\n\n")
                       .arg(title)
                       .arg(deadline)
                       .arg(priority)
                       .arg(finished ? "是" : "否");
    }

    if (taskSummary.isEmpty()) {
        chatTextEdit->append("提示：没有任务记录可供分析。");
        return;
    }

    QString prompt = "以下是我的任务列表，请分析任务是否合理，有没有时间冲突或优先级不当，并给出建议：\n" + taskSummary;

    // 构造 JSON 请求体
    QNetworkRequest request;
    request.setUrl(QUrl("https://api.deepseek.com/v1/chat/completions"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer sk-38236ed25d7341ebb2530bf10b818513"); // ⚠ 替换成安全方式读取！

    QJsonObject jsonPayload;
    jsonPayload["model"] = "deepseek-chat";
    QJsonArray messages;
    messages.append(QJsonObject{
        {"role", "user"},
        {"content", prompt}
    });
    jsonPayload["messages"] = messages;

    QJsonDocument doc(jsonPayload);
    QByteArray requestData = doc.toJson();

    chatTextEdit->append("系统：正在分析日程安排，请稍候...\n");

    networkManager->post(request, requestData);
}
