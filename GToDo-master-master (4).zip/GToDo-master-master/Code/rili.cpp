#include "rili.h"
#include <QVBoxLayout>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QTextCharFormat>
#include <QDate>
#include <QFileDialog>
#include <QPixmap>
#include <QPalette>
#include <QDebug>
#include <QPushButton>
#include <QFileDialog>
#include <QPalette>
#include <QPainter>
#include <QSettings>
#include <QFile>

Rili::Rili(QWidget *parent) : QWidget(parent) {
    this->setFixedSize(1200, 800); // 设置窗口大小

    calendar = new QCalendarWidget(this);
    calendar->setGridVisible(true);
    calendar->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);
    calendar->setHorizontalHeaderFormat(QCalendarWidget::ShortDayNames);
    calendar->setNavigationBarVisible(true);
    calendar->setMinimumDate(QDate::currentDate().addYears(-1));
    calendar->setMaximumDate(QDate::currentDate().addYears(5));

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(calendar);
    setLayout(layout);

    loadTasksFromDatabase();
    highlightDates();
    loadBackground();  // 新增：加载保存的背景图片

    // 创建并连接“设置背景”的按钮
    QPushButton *setBackgroundButton = new QPushButton("设置日历背景", this);
    layout->addWidget(setBackgroundButton);

    connect(setBackgroundButton, &QPushButton::clicked, this, &Rili::setCustomBackground);

    connect(calendar, &QCalendarWidget::clicked, this, [this](const QDate &date) {
        QString dateStr = date.toString("yyyy-MM-dd");

        if (tasksMap.contains(date)) {
            QStringList tasks = tasksMap[date];
            QString message = "📅 日期：" + dateStr + "\n\n📝 以下是该日期的任务：\n";
            for (int i = 0; i < tasks.size(); ++i) {
                message += QString("  %1. %2\n").arg(i + 1).arg(tasks[i]);
            }

            QMessageBox msgBox;
            msgBox.setWindowTitle("任务提醒");
            msgBox.setText(message);
            msgBox.setIcon(QMessageBox::NoIcon);
            msgBox.setStyleSheet(R"(
                QLabel {
                    font-size: 26px;
                    min-width: 400px;
                    min-height: 300px;
                    line-height: 1.6;
                }
                QPushButton {
                    font-size: 16px;
                    padding: 6px 12px;
                }
            )");
            msgBox.exec();
        } else {
            QMessageBox msgBox;
            msgBox.setWindowTitle("任务提醒");
            msgBox.setText("📅 日期：" + dateStr + "\n\n✅ 当前没有任务。");
            msgBox.setIcon(QMessageBox::Information);
            msgBox.setStandardButtons(QMessageBox::Ok);
            msgBox.setIcon(QMessageBox::NoIcon);
            msgBox.setStyleSheet(R"(
                QLabel {
                    font-size: 26px;
                    min-width: 400px;
                    min-height: 300px;
                    line-height: 1.6;
                }
                QPushButton {
                    font-size: 16px;
                    padding: 6px 12px;
                }
            )");
            msgBox.exec();
        }
    });
}

void Rili::loadTasksFromDatabase() {
    QSqlQuery query;
    if (query.exec("SELECT Title, Deadline FROM todolist WHERE Finished = 0")) {
        while (query.next()) {
            QString title = query.value(0).toString();
            QDate deadline = QDate::fromString(query.value(1).toString(), "yyyy-MM-dd");
            if (deadline.isValid()) {
                tasksMap[deadline].append(title);
            }
        }
    } else {
        qDebug() << "Database error:" << query.lastError().text();
    }
}

void Rili::highlightDates() {
    QTextCharFormat taskFormat;
    taskFormat.setBackground(QBrush(Qt::yellow));
    taskFormat.setForeground(Qt::black);

    QTextCharFormat todayFormat;
    todayFormat.setBackground(QColor(204, 255, 204)); // 淡绿色
    todayFormat.setForeground(Qt::black);
    calendar->setDateTextFormat(QDate::currentDate(), todayFormat); // 设置今天

    for (const QDate &date : tasksMap.keys()) {
        QTextCharFormat format = calendar->dateTextFormat(date);
        format.setBackground(QBrush(Qt::yellow)); // 黄色背景
        calendar->setDateTextFormat(date, format);
    }
}

void Rili::setCustomBackground() {
    QString filePath = QFileDialog::getOpenFileName(this, "选择背景图片", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)");

    if (!filePath.isEmpty()) {
        QPixmap pixmap(filePath);
        if (!pixmap.isNull()) {
            // 将背景图缩放为固定尺寸1200x800
            QPixmap scaled = pixmap.scaled(1200, 800, Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation);

            if (!backgroundLabel) {
                backgroundLabel = new QLabel(calendar);
                backgroundLabel->setGeometry(0, 0, 1200, 800);  // 固定大小为1200x800
                backgroundLabel->setScaledContents(true);
                backgroundLabel->setAttribute(Qt::WA_TransparentForMouseEvents);
                backgroundLabel->raise();
            }

            QPixmap transparentPixmap(scaled.size());
            transparentPixmap.fill(Qt::transparent);

            QPainter painter(&transparentPixmap);
            painter.setOpacity(0.4);  // 设置透明度
            painter.drawPixmap(0, 0, scaled);
            painter.end();

            backgroundLabel->setPixmap(transparentPixmap);
            backgroundLabel->show();

            // 保存路径
            QSettings settings("MyCompany", "MyCalendarApp");
            settings.setValue("calendarBackground", filePath);
        } else {
            QMessageBox::warning(this, "错误", "无法加载图片，请确保文件格式正确。");
        }
    }
}

void Rili::loadBackground() {
    QSettings settings("MyCompany", "MyCalendarApp");
    QString filePath = settings.value("calendarBackground").toString();

    if (!filePath.isEmpty() && QFile::exists(filePath)) {
        QPixmap pixmap(filePath);
        if (!pixmap.isNull()) {
            // 将背景图缩放为固定尺寸1200x800
            QPixmap scaled = pixmap.scaled(1200, 800, Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation);

            if (!backgroundLabel) {
                backgroundLabel = new QLabel(calendar);
                backgroundLabel->setGeometry(0, 0, 1200, 800);  // 固定大小为1200x800
                backgroundLabel->setScaledContents(true);
                backgroundLabel->setAttribute(Qt::WA_TransparentForMouseEvents);
                backgroundLabel->raise();
            }

            QPixmap transparentPixmap(scaled.size());
            transparentPixmap.fill(Qt::transparent);

            QPainter painter(&transparentPixmap);
            painter.setOpacity(0.4);  // 设置透明度
            painter.drawPixmap(0, 0, scaled);
            painter.end();

            backgroundLabel->setPixmap(transparentPixmap);
            backgroundLabel->show();
        }
    }
}
