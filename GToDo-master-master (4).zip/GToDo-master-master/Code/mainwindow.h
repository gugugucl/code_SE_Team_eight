#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void clickedSlot();
    void replyFinished(QNetworkReply *reply);

private:
    QTextEdit *chatTextEdit;
    QTextEdit *inputTextEdit;
    QPushButton *sendButton;
    QNetworkAccessManager *networkManager;
private slots:
    void evaluateScheduleSlot(); // 新增槽

private:
    QPushButton *evaluateButton;
};

#endif // MAINWINDOW_H
